package com.netthrottle.app
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.graphics.drawable.toBitmap

data class AppItem(val name: String, val pkg: String, val icon: androidx.compose.ui.graphics.ImageBitmap)

class MainActivity : ComponentActivity() {
    private var pending: (() -> Unit)? = null
    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) pending?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }.distinctBy { it.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.packageName, it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()) }
            .sortedBy { it.name.lowercase() }
    }

    private fun start(pkgs: Set<String>, dl: Long, ul: Long, ping: Int) {
        val go = {
            startService(Intent(this, ThrottleService::class.java).putExtra("pkgs", pkgs.toTypedArray())
                .putExtra("dl", dl).putExtra("ul", ul).putExtra("ping", ping))
        }
        val p = VpnService.prepare(this)
        if (p == null) go() else { pending = { go() }; launcher.launch(p) }
    }

    @Composable
    fun Screen() {
        val prefs = remember { getSharedPreferences("p", 0) }
        val apps = remember { loadApps() }
        var dl by remember { mutableStateOf(prefs.getFloat("dl", 0f)) }
        var ul by remember { mutableStateOf(prefs.getFloat("ul", 0f)) }
        var ping by remember { mutableStateOf(prefs.getFloat("ping", 0f)) }
        var sel by remember { mutableStateOf(prefs.getStringSet("sel", emptySet())!!.toSet()) }
        var q by remember { mutableStateOf("") }
        fun save() = prefs.edit().putFloat("dl", dl).putFloat("ul", ul).putFloat("ping", ping).putStringSet("sel", sel).apply()
        fun lbl(v: Float, u: String) = if (v < 1f) "Unlimited" else "${v.toInt()} $u"

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
            Text("NetThrottle", style = MaterialTheme.typography.headlineMedium)
            Text("Limit speed and add ping for selected apps", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text("Download: ${lbl(dl, "KB/s")}")
            Slider(dl, { dl = it }, valueRange = 0f..5000f)
            Text("Upload: ${lbl(ul, "KB/s")}")
            Slider(ul, { ul = it }, valueRange = 0f..5000f)
            Text("Added ping: ${if (ping < 1f) "None" else "${ping.toInt()} ms"}")
            Slider(ping, { ping = it }, valueRange = 0f..1000f)
            Text("0 = unlimited / none. Slide to set limits, then press Start.", style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = {
                    save()
                    prefs.edit().putBoolean("on", !ThrottleService.running).apply()
                    if (ThrottleService.running) startService(Intent(this@MainActivity, ThrottleService::class.java).setAction("STOP"))
                    else if (sel.isNotEmpty()) start(sel, dl.toLong(), ul.toLong(), ping.toInt())
                },
                enabled = ThrottleService.running || sel.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (ThrottleService.running) "Stop" else "Start (${sel.size} apps)") }
            OutlinedTextField(q, { q = it }, label = { Text("Search apps") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            LazyColumn(Modifier.weight(1f)) {
                items(apps.filter { it.name.contains(q, true) }, key = { it.pkg }) { a ->
                    Row(Modifier.fillMaxWidth().clickable { sel = if (a.pkg in sel) sel - a.pkg else sel + a.pkg; save() }
                        .padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(a.icon, null, Modifier.size(40.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(a.name, Modifier.weight(1f))
                        Checkbox(a.pkg in sel, { sel = if (it) sel + a.pkg else sel - a.pkg; save() })
                    }
                }
            }
        }
    }
}
