package com.aero.netlimiter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.net.VpnService
import android.os.PowerManager
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private class AppItem(val pkg: String, val label: String, val icon: Drawable)

    private val apps = ArrayList<AppItem>()
    private val sel = HashSet<String>()
    private val steps = intArrayOf(16, 32, 64, 128, 256, 512, 1024, 2048, 5120, 0)
    private lateinit var btn: Button
    private lateinit var prefs: android.content.SharedPreferences

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lbl(k: Int) = if (k == 0) "Unlimited" else if (k >= 1024) "${k / 1024} MB/s" else "$k KB/s"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", MODE_PRIVATE)
        sel.addAll(prefs.getStringSet("sel", emptySet()) ?: emptySet())

        val pm = packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(li, 0).map { it.activityInfo.packageName }.distinct()
            .filter { it != packageName }
            .forEach { apps.add(AppItem(it, pm.getApplicationInfo(it, 0).loadLabel(pm).toString(), pm.getApplicationIcon(it))) }
        apps.sortBy { it.label.lowercase() }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(36), dp(16), dp(12)) }
        root.addView(TextView(this).apply { text = "Net Limiter"; textSize = 24f; setTextColor(Color.BLACK) })

        fun slider(title: String, max: Int, key: String, def: Int, text: (Int) -> String, apply: (Int) -> Unit) {
            val t = TextView(this).apply { setPadding(0, dp(10), 0, 0) }
            val sb = SeekBar(this).apply { this.max = max; progress = prefs.getInt(key, def) }
            fun upd(p: Int) { t.text = "$title: ${text(p)}"; apply(p) }
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { upd(p); prefs.edit().putInt(key, p).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            upd(sb.progress)
            root.addView(t); root.addView(sb)
        }
        slider("Download", steps.size - 1, "d", steps.size - 1, { lbl(steps[it]) }) { Cfg.downKBps = steps[it] }
        slider("Upload", steps.size - 1, "u", steps.size - 1, { lbl(steps[it]) }) { Cfg.upKBps = steps[it] }
        slider("Extra ping", 50, "g", 0, { if (it == 0) "0 ms" else "+${it * 10} ms" }) { Cfg.pingMs = it * 10 }

        root.addView(TextView(this).apply { text = "Select apps"; textSize = 16f; setPadding(0, dp(14), 0, dp(4)); setTextColor(Color.BLACK) })

        val list = ListView(this)
        list.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val a = apps[i]
                val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
                row.addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon); layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)) })
                row.addView(TextView(this@MainActivity).apply {
                    text = a.label; textSize = 15f; setPadding(dp(12), 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(CheckBox(this@MainActivity).apply { isChecked = a.pkg in sel; isClickable = false; isFocusable = false })
                return row
            }
        }
        list.setOnItemClickListener { _, _, i, _ ->
            val p = apps[i].pkg
            if (!sel.add(p)) sel.remove(p)
            prefs.edit().putStringSet("sel", HashSet(sel)).apply()
            (list.adapter as BaseAdapter).notifyDataSetChanged()
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        btn = Button(this)
        btn.setOnClickListener {
            if (LimiterVpnService.running) {
                prefs.edit().putBoolean("auto", false).apply()
                startService(Intent(this, LimiterVpnService::class.java).setAction("stop"))
                btn.postDelayed({ refresh() }, 400)
            } else if (sel.isEmpty()) {
                Toast.makeText(this, "Select at least one app", Toast.LENGTH_SHORT).show()
            } else {
                val i = VpnService.prepare(this)
                if (i != null) startActivityForResult(i, 1) else startVpn()
            }
        }
        root.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        setContentView(root)
        refresh()
        askPermissions()
    }

    private fun askPermissions() {
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 2) else askBattery()
    }

    private fun askBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName) || prefs.getBoolean("battAsked", false)) return
        prefs.edit().putBoolean("battAsked", true).apply()
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (_: Exception) {}
    }

    private fun startVpn() {
        prefs.edit().putBoolean("auto", true).apply()
        startService(Intent(this, LimiterVpnService::class.java).putExtra("pkgs", sel.toTypedArray()))
        btn.postDelayed({ refresh() }, 600)
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        if (req == 1 && res == RESULT_OK) startVpn()
        if (req == 2) askBattery()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() { btn.text = if (LimiterVpnService.running) "STOP" else "START" }
}
