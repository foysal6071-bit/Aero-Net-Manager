package com.aero.netlimiter

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

object Cfg {
    @Volatile var downKBps = 0   // 0 = unlimited
    @Volatile var upKBps = 0
    @Volatile var pingMs = 0     // extra delay added
}

class RateLimiter(private val kbps: () -> Int) {
    private var next = 0L
    fun acquire(n: Int) {
        val r = kbps() * 1024L
        if (r <= 0) return
        val wait: Long
        synchronized(this) {
            val now = System.nanoTime()
            if (next < now) next = now
            wait = next - now
            next += n * 1_000_000_000L / r
        }
        if (wait > 0) try { Thread.sleep(wait / 1_000_000, (wait % 1_000_000).toInt()) } catch (_: InterruptedException) {}
    }
}

private const val M = 0xffffffffL
private const val FIN = 1; private const val SYN = 2; private const val RST = 4
private const val PSH = 8; private const val ACK = 16

private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
private fun put32(b: ByteArray, o: Int, v: Long) {
    b[o] = (v shr 24).toByte(); b[o + 1] = (v shr 16).toByte(); b[o + 2] = (v shr 8).toByte(); b[o + 3] = v.toByte()
}
private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
private fun u32(b: ByteArray, o: Int): Long =
    ((b[o].toLong() and 255) shl 24) or ((b[o + 1].toLong() and 255) shl 16) or
        ((b[o + 2].toLong() and 255) shl 8) or (b[o + 3].toLong() and 255)

private fun csum(b: ByteArray, off: Int, len: Int): Int {
    var s = 0L; var i = off; val end = off + len
    while (i + 1 < end) { s += ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255); i += 2 }
    if (i < end) s += (b[i].toInt() and 255) shl 8
    while (s shr 16 != 0L) s = (s and 0xffff) + (s shr 16)
    return (s.inv() and 0xffff).toInt()
}

private fun l4sum(src: ByteArray, dst: ByteArray, proto: Int, t: ByteArray): Int {
    val p = ByteArray(12 + t.size)
    System.arraycopy(src, 0, p, 0, 4); System.arraycopy(dst, 0, p, 4, 4)
    p[9] = proto.toByte(); put16(p, 10, t.size)
    System.arraycopy(t, 0, p, 12, t.size)
    return csum(p, 0, p.size)
}

private fun ipPkt(src: ByteArray, dst: ByteArray, proto: Int, l4: ByteArray): ByteArray {
    val total = 20 + l4.size
    val p = ByteArray(total)
    p[0] = 0x45; put16(p, 2, total); p[6] = 0x40; p[8] = 64; p[9] = proto.toByte()
    System.arraycopy(src, 0, p, 12, 4); System.arraycopy(dst, 0, p, 16, 4)
    put16(p, 10, csum(p, 0, 20))
    System.arraycopy(l4, 0, p, 20, l4.size)
    return p
}

private fun tcpPkt(
    src: ByteArray, dst: ByteArray, sp: Int, dp: Int, seq: Long, ack: Long,
    flags: Int, data: ByteArray?, len: Int, mss: Boolean
): ByteArray {
    val hl = if (mss) 24 else 20
    val t = ByteArray(hl + len)
    put16(t, 0, sp); put16(t, 2, dp); put32(t, 4, seq); put32(t, 8, ack)
    t[12] = ((hl / 4) shl 4).toByte(); t[13] = flags.toByte(); put16(t, 14, 65535)
    if (mss) { t[20] = 2; t[21] = 4; put16(t, 22, 1360) }
    if (data != null) System.arraycopy(data, 0, t, hl, len)
    put16(t, 16, l4sum(src, dst, 6, t))
    return ipPkt(src, dst, 6, t)
}

private class Item(val data: ByteArray?, val ackTo: Long, val readyAt: Long)

class LimiterVpnService : VpnService() {
    companion object { @Volatile var running = false }

    private var tun: ParcelFileDescriptor? = null
    private var tout: FileOutputStream? = null
    private val lock = Any()
    private val tcpMap = ConcurrentHashMap<String, Tcp>()
    private val udpMap = ConcurrentHashMap<String, Udp>()
    private var sched = Executors.newSingleThreadScheduledExecutor()
    private var pool = Executors.newCachedThreadPool()
    private val down = RateLimiter { Cfg.downKBps }
    private val up = RateLimiter { Cfg.upKBps }
    @Volatile private var alive = false

    private fun half() = (Cfg.pingMs + 1) / 2

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { stopVpn(); stopSelf(); return START_NOT_STICKY }
        val pk = intent?.getStringArrayExtra("pkgs") ?: emptyArray()
        if (pk.isEmpty()) { stopSelf(); return START_NOT_STICKY }
        startVpn(pk)
        return START_NOT_STICKY
    }

    private fun startVpn(pk: Array<String>) {
        stopVpn()
        val b = Builder().setSession("Net Limiter").setMtu(1400)
            .addAddress("10.8.0.2", 32).addRoute("0.0.0.0", 0).addDnsServer("8.8.8.8")
        for (p in pk) try { b.addAllowedApplication(p) } catch (_: Exception) {}
        val fd = b.establish() ?: return
        tun = fd
        tout = FileOutputStream(fd.fileDescriptor)
        sched = Executors.newSingleThreadScheduledExecutor()
        pool = Executors.newCachedThreadPool()
        alive = true; running = true
        Thread {
            val inp = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            while (alive) {
                val n = try { inp.read(buf) } catch (_: Exception) { -1 }
                if (n < 0) break
                if (n < 20 || (buf[0].toInt() shr 4) != 4) continue
                try { handle(buf.copyOf(n)) } catch (_: Exception) {}
            }
        }.start()
    }

    private fun stopVpn() {
        alive = false; running = false
        tcpMap.values.forEach { it.close() }; tcpMap.clear()
        udpMap.values.forEach { it.close() }; udpMap.clear()
        try { tun?.close() } catch (_: Exception) {}
        tun = null; tout = null
        sched.shutdownNow(); pool.shutdownNow()
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    private fun writeTun(p: ByteArray) = synchronized(lock) { try { tout?.write(p) } catch (_: Exception) {} }

    private fun emit(p: ByteArray, delay: Int) {
        if (delay <= 0) writeTun(p)
        else try { sched.schedule({ writeTun(p) }, delay.toLong(), TimeUnit.MILLISECONDS) } catch (_: Exception) {}
    }

    private fun handle(p: ByteArray) {
        val ihl = (p[0].toInt() and 15) * 4
        val proto = p[9].toInt() and 255
        val total = u16(p, 2).coerceAtMost(p.size)
        val cip = p.copyOfRange(12, 16)
        val sip = p.copyOfRange(16, 20)
        val dstStr = InetAddress.getByAddress(sip).hostAddress
        if (proto == 6) {
            val cport = u16(p, ihl); val sport = u16(p, ihl + 2)
            val seq = u32(p, ihl + 4); val ackN = u32(p, ihl + 8)
            val off = ((p[ihl + 12].toInt() and 255) shr 4) * 4
            val fl = p[ihl + 13].toInt() and 255
            val win = u16(p, ihl + 14)
            val plen = total - ihl - off
            val key = "$cport>$dstStr:$sport"
            var s = tcpMap[key]
            if (fl and SYN != 0 && fl and ACK == 0) {
                if (s == null) {
                    s = Tcp(key, cip, sip, cport, sport, seq)
                    s.window = win
                    tcpMap[key] = s
                    s.start()
                }
                return
            }
            if (s == null) return
            if (fl and RST != 0) { s.close(); return }
            if (fl and ACK != 0) { s.lastAck = ackN; s.window = if (win == 0) 1 else win }
            if (plen > 0) {
                if (seq == s.rcvNext) {
                    s.rcvNext = (s.rcvNext + plen) and M
                    s.q.add(Item(p.copyOfRange(ihl + off, ihl + off + plen), s.rcvNext, System.currentTimeMillis() + half()))
                } else s.sendAck()
            }
            if (fl and FIN != 0 && !s.finQueued && ((seq + maxOf(plen, 0)) and M) == s.rcvNext) {
                s.finQueued = true
                s.rcvNext = (s.rcvNext + 1) and M
                s.q.add(Item(null, s.rcvNext, System.currentTimeMillis() + half()))
            }
        } else if (proto == 17) {
            val cport = u16(p, ihl); val sport = u16(p, ihl + 2)
            val plen = u16(p, ihl + 4) - 8
            if (plen < 0) return
            val key = "$cport>$dstStr:$sport"
            var u = udpMap[key]
            if (u == null) {
                u = Udp(key, cip, sip, cport, sport)
                if (!u.open()) return
                udpMap[key] = u
            }
            u.send(p.copyOfRange(ihl + 8, ihl + 8 + plen))
        }
    }

    inner class Tcp(
        val key: String, val cip: ByteArray, val sip: ByteArray,
        val cport: Int, val sport: Int, isn: Long
    ) {
        @Volatile var rcvNext = (isn + 1) and M
        @Volatile var ackSent = rcvNext
        @Volatile var ourSeq = 0L
        @Volatile var lastAck = 0L
        @Volatile var window = 65535
        @Volatile var closed = false
        @Volatile var finSent = false
        @Volatile var finRcvd = false
        var finQueued = false
        val q = LinkedBlockingQueue<Item>()
        var sock: Socket? = null

        private fun send(flags: Int, data: ByteArray?, len: Int, mss: Boolean = false, delay: Int = half()) {
            synchronized(this) {
                val pkt = tcpPkt(sip, cip, sport, cport, ourSeq, ackSent, flags, data, len, mss)
                ourSeq = (ourSeq + len + (if (flags and (SYN or FIN) != 0) 1 else 0)) and M
                emit(pkt, delay)
            }
        }

        fun sendAck() { if (!closed) send(ACK, null, 0) }

        fun start() {
            Thread {
                val s = Socket()
                try {
                    protect(s)
                    s.connect(InetSocketAddress(InetAddress.getByAddress(sip), sport), 10000)
                    s.tcpNoDelay = true
                } catch (_: Exception) {
                    try { s.close() } catch (_: Exception) {}
                    synchronized(this) {
                        emit(tcpPkt(sip, cip, sport, cport, 0, rcvNext, RST or ACK, null, 0, false), 0)
                    }
                    tcpMap.remove(key); return@Thread
                }
                sock = s
                if (Cfg.pingMs > 0) try { Thread.sleep(Cfg.pingMs.toLong()) } catch (_: Exception) {}
                ourSeq = (System.nanoTime() and 0x7fffffffL)
                ackSent = rcvNext
                send(SYN or ACK, null, 0, true, 0)
                lastAck = ourSeq
                Thread { writer(s) }.start()
                reader(s)
            }.start()
        }

        private fun writer(s: Socket) {
            try {
                val out = s.getOutputStream()
                while (!closed) {
                    val it = q.take()
                    val w = it.readyAt - System.currentTimeMillis()
                    if (w > 0) Thread.sleep(w)
                    if (it.data == null) {
                        try { s.shutdownOutput() } catch (_: Exception) {}
                        ackSent = it.ackTo; sendAck()
                        finRcvd = true; check()
                        break
                    }
                    up.acquire(it.data.size)
                    out.write(it.data)
                    ackSent = it.ackTo; sendAck()
                }
            } catch (_: Exception) { close() }
        }

        private fun reader(s: Socket) {
            try {
                val inp = s.getInputStream()
                val buf = ByteArray(1360)
                while (!closed) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    down.acquire(n)
                    while (!closed && ((ourSeq - lastAck) and M) >= window) Thread.sleep(3)
                    send(PSH or ACK, buf, n)
                }
                if (!closed) { send(FIN or ACK, null, 0); finSent = true; check() }
            } catch (_: Exception) { close() }
        }

        private fun check() { if (finSent && finRcvd) close() }

        fun close() {
            closed = true
            try { sock?.close() } catch (_: Exception) {}
            q.offer(Item(ByteArray(0), 0, 0))
            tcpMap.remove(key)
        }
    }

    inner class Udp(val key: String, val cip: ByteArray, val sip: ByteArray, val cport: Int, val sport: Int) {
        private var ds: DatagramSocket? = null
        fun open(): Boolean {
            val d = try { DatagramSocket().also { protect(it); it.soTimeout = 30000 } } catch (_: Exception) { return false }
            ds = d
            pool.execute {
                val buf = ByteArray(65535)
                try {
                    while (alive) {
                        val pk = DatagramPacket(buf, buf.size)
                        d.receive(pk)
                        down.acquire(pk.length)
                        val u = ByteArray(8 + pk.length)
                        put16(u, 0, sport); put16(u, 2, cport); put16(u, 4, u.size)
                        System.arraycopy(buf, 0, u, 8, pk.length)
                        emit(ipPkt(sip, cip, 17, u), half())
                    }
                } catch (_: Exception) {}
                close()
            }
            return true
        }

        fun send(data: ByteArray) {
            val d = ds ?: return
            try {
                pool.execute {
                    try {
                        if (Cfg.pingMs > 0) Thread.sleep(half().toLong())
                        up.acquire(data.size)
                        d.send(DatagramPacket(data, data.size, InetAddress.getByAddress(sip), sport))
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
        }

        fun close() { try { ds?.close() } catch (_: Exception) {}; udpMap.remove(key) }
    }
}
