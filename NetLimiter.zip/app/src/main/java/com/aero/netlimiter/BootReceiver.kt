package com.aero.netlimiter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != "android.intent.action.QUICKBOOT_POWERON") return
        val p = c.getSharedPreferences("p", Context.MODE_PRIVATE)
        if (!p.getBoolean("auto", false)) return
        val sel = p.getStringSet("sel", emptySet()) ?: emptySet()
        if (sel.isEmpty()) return
        if (VpnService.prepare(c) != null) return // VPN permission not granted
        val steps = intArrayOf(16, 32, 64, 128, 256, 512, 1024, 2048, 5120, 0)
        Cfg.downKBps = steps[p.getInt("d", 9).coerceIn(0, 9)]
        Cfg.upKBps = steps[p.getInt("u", 9).coerceIn(0, 9)]
        Cfg.pingMs = p.getInt("g", 0) * 10
        c.startService(Intent(c, LimiterVpnService::class.java).putExtra("pkgs", sel.toTypedArray()))
    }
}
