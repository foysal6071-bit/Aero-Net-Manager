# Aero Net Manager

AeroHUB-এর সাথে কাজ করে। প্রতিটা app-এর internet আলাদা করে নিয়ন্ত্রণ করা যায় (নিজস্ব local VPN দিয়ে)।

## Build
সব ফাইল GitHub repo-তে upload করুন; `main`-এ push করলে Actions APK বানিয়ে Releases-এ দেবে।

## শুরু
1. AeroHUB-এর server চালু করুন।
2. Aero Net Manager → **Connect AeroHUB** → Allow।
3. **Internet control (VPN)** চালু করুন।

## ফিচার (UI: কার্ড, রঙিন chip, লাইভ গতির টাইল)
**সব app-এর জন্য**
- All other apps: বাকি সব app-এর সীমা (Unlimited / Block / 50 KB/s … 5 MB/s / custom)
- দ্রুত বোতাম: Normal, Save data (100 KB/s), Block others (শুধু আপনার দেওয়া app চলবে)
- Night schedule: নির্দিষ্ট সময়ে (যেমন 23:00–06:00) সব app Block বা ধীর (Unlimited করা app বাদে)
- লাইভ ↓/↑ গতি ও আজকের মোট ব্যবহার
- Reset today's usage, Reset all rules
- Hide VPN icon (AeroHUB দিয়ে)

**প্রতিটা app-এ ট্যাপ করলে**
- Speed limit (Unlimited হলে VPN-এর বাইরে চলে, সর্বোচ্চ গতি)
- Network: Wi-Fi + Mobile / শুধু Wi-Fi / শুধু Mobile data
- Daily data quota: সীমা পার হলে ওই app block, মধ্যরাতে রিসেট
- Background data: Block/Allow (AeroHUB দিয়ে system-এর per-app policy; মূলত mobile/metered network-এ কাজ করে)
- আজ কত data ব্যবহার করেছে
- Force stop
- ওই app-এর সব rule reset
- তালিকা A–Z বা সবচেয়ে বেশি ব্যবহার অনুযায়ী সাজানো যায়

## সীমাবদ্ধতা
- লাইনের speed-এর বেশি হয় না; "বাড়ানো" = অন্যদের কমিয়ে প্রিয় app-কে বেশি ভাগ দেওয়া।
- Rule বদলালে VPN আবার তৈরি হয়, তাই চলমান connection কয়েক সেকেন্ডের জন্য কাটতে পারে।
- Quota/network/night-এর block প্রায় ৫ সেকেন্ডের মধ্যে চলমান connection-এও কাজ করে।
- Data ব্যবহার শুধু VPN-এর ভেতর দিয়ে যাওয়া traffic গোনে (Unlimited app গোনা হয় না, যদি তার quota না থাকে)।
- VPN icon লুকানো ROM-এর উপর নির্ভর করে; VPN-এর notification লুকানো যায় না।
- IPv6 বন্ধ রাখা হয়, ICMP (ping) চলে না।
