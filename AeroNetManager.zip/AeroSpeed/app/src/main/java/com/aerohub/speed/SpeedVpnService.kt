package com.aerohub.speed

import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue

/**
 * Local VPN that forwards traffic itself (no remote server) and limits the speed per app.
 * Apps set to "Unlimited" are excluded from the VPN, so they run at full speed.
 */
class SpeedVpnService : VpnService() {
    companion object {
        const val ACT_START = "com.aerohub.speed.START"
        const val ACT_STOP = "com.aerohub.speed.STOP"
        @Volatile var running = false
    }

    private var pfd: ParcelFileDescriptor? = null
    private var engine: Engine? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_STOP) { stopAll(); stopSelf(); return START_NOT_STICKY }
        startAll()
        return START_NOT_STICKY
    }

    override fun onRevoke() { stopAll(); super.onRevoke() }
    override fun onDestroy() { stopAll(); super.onDestroy() }

    private fun stopAll() {
        running = false
        engine?.stop(); engine = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
    }

    private fun startAll() {
        stopAll()
        val def = Rules.default(this)
        val nightOn = Rules.nightOn(this)
        val b = Builder().setSession("Aero Net Manager").setMtu(1500).setBlocking(true)
            .addAddress("10.77.0.2", 32).addRoute("0.0.0.0", 0).addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
        // IPv6 is captured and dropped, so apps fall back to IPv4 (which we can limit)
        try { b.addAddress("fd77:77:77::2", 128).addRoute("::", 0) } catch (_: Exception) {}
        val uidRules = HashMap<Int, R>()
        val rules = HashMap<String, R>()
        for (pkg in Rules.packagesWithRules(this)) {
            val r = R(Rules.get(this, pkg), Rules.net(this, pkg), Rules.quota(this, pkg))
            rules[pkg] = r
            try { uidRules[packageManager.getApplicationInfo(pkg, 0).uid] = r } catch (_: Exception) {}
        }
        // an app needs the VPN if it has a limit/block, a network rule or a quota
        fun needs(r: R) = (r.limit != Rules.UNLIMITED && r.limit != Rules.DEFAULT) || r.net != 0 || r.quotaMB > 0
        try {
            if (def == Rules.UNLIMITED && !nightOn) {
                var n = 0
                for ((pkg, r) in rules) if (needs(r)) { try { b.addAllowedApplication(pkg); n++ } catch (_: Exception) {} }
                if (n == 0) b.addAllowedApplication(packageName)
            } else {
                b.addDisallowedApplication(packageName)
                for ((pkg, r) in rules) if (r.limit == Rules.UNLIMITED && !needs(r)) { try { b.addDisallowedApplication(pkg) } catch (_: Exception) {} }
            }
        } catch (_: Exception) {}
        val f = b.establish() ?: return
        pfd = f
        running = true
        engine = Engine(f, uidRules, def, nightOn).also { it.start() }
    }

    // ===================================================================================
    private class Bucket(rateKBps: Long) {
        private val rate = (rateKBps * 1024).coerceAtLeast(1024)
        private val cap = (rate / 2).coerceAtLeast(16384)
        private var tokens = cap.toDouble()
        private var last = System.nanoTime()
        private fun refill() { val n = System.nanoTime(); tokens = minOf(cap.toDouble(), tokens + (n - last) / 1e9 * rate); last = n }
        /** Takes n bytes and returns how many ms the caller must wait. */
        @Synchronized fun reserve(n: Int): Long { refill(); tokens -= n; return if (tokens >= 0) 0 else (-tokens * 1000 / rate).toLong() }
        /** For UDP: take n bytes only if available. */
        @Synchronized fun tryTake(n: Int): Boolean { refill(); return if (tokens >= n) { tokens -= n; true } else false }
    }

    private data class Key(val src: Int, val sp: Int, val dst: Int, val dp: Int)
    private class Pair2(val down: Bucket, val up: Bucket)
    private class R(val limit: Long, val net: Int, val quotaMB: Long)

    private inner class Engine(val fd: ParcelFileDescriptor, val uidRules: Map<Int, R>, val def: Long, val nightOn: Boolean) {
        @Volatile var alive = true
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val pool = Executors.newCachedThreadPool { r -> Thread(r).apply { isDaemon = true } }
        val tcps = ConcurrentHashMap<Key, Tcp>()
        val udps = ConcurrentHashMap<Key, Udp>()
        val uidBuckets = ConcurrentHashMap<Int, Pair2>()
        val defBuckets: Pair2? = if (def > 0) Pair2(Bucket(def), Bucket(def)) else null
        val cm = getSystemService(ConnectivityManager::class.java)

        fun start() {
            Stats.load(this@SpeedVpnService)
            nightActive = isNightTime()
            try { cm.registerNetworkCallback(NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb) } catch (_: Exception) {}
            pool.execute { loop() }; pool.execute { sweep() }
        }

        fun stop() {
            alive = false
            try { cm.unregisterNetworkCallback(netCb) } catch (_: Exception) {}
            Stats.save(this@SpeedVpnService)
            tcps.values.forEach { it.close() }; udps.values.forEach { it.close() }
            tcps.clear(); udps.clear()
            pool.shutdownNow()
        }

        fun write(p: ByteArray) { try { synchronized(output) { output.write(p) } } catch (_: Exception) {} }

        // ---- rules
        val nightLimit = Rules.nightLimit(this@SpeedVpnService)
        val nightBuckets: Pair2? = if (nightLimit > 0) Pair2(Bucket(nightLimit), Bucket(nightLimit)) else null
        @Volatile var nightActive = false
        @Volatile var curNet = 0                                // 0 unknown, 1 Wi-Fi, 2 mobile
        val pkgCache = ConcurrentHashMap<Int, String>()
        val netTypes = ConcurrentHashMap<Network, Int>()

        fun pkgOf(uid: Int): String = pkgCache.getOrPut(uid) { packageManager.getPackagesForUid(uid)?.firstOrNull() ?: "uid:$uid" }
        fun nightNow(uid: Int) = nightOn && nightActive && uidRules[uid]?.limit != Rules.UNLIMITED
        fun baseLimit(uid: Int): Long { val r = uidRules[uid]; return if (r == null || r.limit == Rules.DEFAULT) def else r.limit }
        fun limitFor(uid: Int): Long = if (nightNow(uid)) nightLimit else baseLimit(uid)
        fun bucketsFor(uid: Int): Pair2? {
            if (limitFor(uid) <= 0) return null
            if (nightNow(uid)) return nightBuckets
            val r = uidRules[uid]
            return if (r != null && r.limit > 0) uidBuckets.getOrPut(uid) { Pair2(Bucket(r.limit), Bucket(r.limit)) } else defBuckets
        }
        fun blocked(uid: Int): Boolean {
            if (limitFor(uid) == Rules.BLOCK) return true
            val r = uidRules[uid] ?: return false
            if (r.net == 1 && curNet == 2) return true
            if (r.net == 2 && curNet == 1) return true
            if (r.quotaMB > 0 && Stats.usage(pkgOf(uid)) >= r.quotaMB * 1048576L) return true
            return false
        }
        fun count(uid: Int, n: Int, isDown: Boolean) { Stats.add(pkgOf(uid), n.toLong(), isDown) }

        fun isNightTime(): Boolean {
            val c = java.util.Calendar.getInstance(); val m = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
            val s0 = Rules.nightStart(this@SpeedVpnService); val e0 = Rules.nightEnd(this@SpeedVpnService)
            return if (s0 == e0) false else if (s0 < e0) m in s0 until e0 else (m >= s0 || m < e0)
        }

        val netCb = object : ConnectivityManager.NetworkCallback() {
            fun recompute() {
                val v = netTypes.values
                curNet = if (v.contains(1)) 1 else if (v.contains(2)) 2 else 0
            }
            override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) {
                netTypes[n] = if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) 1
                              else if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) 2 else 0
                recompute()
            }
            override fun onLost(n: Network) { netTypes.remove(n); recompute() }
        }

        fun owner(proto: Int, k: Key): Int = try {
            cm.getConnectionOwnerUid(proto, InetSocketAddress(addr(k.src), k.sp), InetSocketAddress(addr(k.dst), k.dp))
        } catch (_: Exception) { -1 }

        fun sweep() {
            var tick = 0
            while (alive) {
                try { Thread.sleep(5000) } catch (_: InterruptedException) { return }
                tick++
                nightActive = isNightTime()
                Stats.rollover()
                if (tick % 3 == 0) Stats.save(this@SpeedVpnService)
                val now = System.currentTimeMillis()
                // flows that are no longer allowed (quota reached, night mode, network changed) are cut right away
                tcps.entries.removeIf { if (now - it.value.last > 180000 || blocked(it.value.uid)) { it.value.close(); true } else false }
                udps.entries.removeIf { if (now - it.value.last > 40000 || blocked(it.value.uid)) { it.value.close(); true } else false }
            }
        }

        fun loop() {
            val buf = ByteArray(32768)
            while (alive) {
                val n = try { input.read(buf) } catch (_: Exception) { break }
                if (n <= 0) continue
                try { handle(buf, n) } catch (_: Exception) {}
            }
        }

        fun handle(b: ByteArray, n: Int) {
            if ((b[0].toInt() ushr 4) != 4) return                       // IPv6: dropped
            val ihl = (b[0].toInt() and 15) * 4
            val total = u16(b, 2).coerceAtMost(n)
            if ((u16(b, 6) and 0x3fff) != 0) return                      // fragments: dropped
            val proto = b[9].toInt() and 255
            val src = i32(b, 12); val dst = i32(b, 16)
            if (proto == 6) {
                val sp = u16(b, ihl); val dp = u16(b, ihl + 2)
                val seq = i32(b, ihl + 4); val ack = i32(b, ihl + 8)
                val off = (b[ihl + 12].toInt() ushr 4) * 4
                val fl = b[ihl + 13].toInt() and 63
                val win = u16(b, ihl + 14)
                val pStart = ihl + off; val plen = (total - pStart).coerceAtLeast(0)
                val key = Key(src, sp, dst, dp)
                if (fl and 2 != 0 && fl and 16 == 0) {                   // SYN
                    if (tcps.containsKey(key)) return
                    val uid = owner(OsConstants.IPPROTO_TCP, key)
                    if (blocked(uid)) { write(tcpPacket(dst, src, dp, sp, 0, seq + 1, 4 or 16, 0, null, 0, 0, false)); return }
                    val t = Tcp(key, uid, seq, win)
                    tcps[key] = t
                    pool.execute { t.connect() }
                    return
                }
                val t = tcps[key]
                if (t == null) { if (plen > 0 && fl and 4 == 0) write(tcpPacket(dst, src, dp, sp, ack, seq + plen, 4 or 16, 0, null, 0, 0, false)); return }
                t.onPacket(fl, seq, ack, win, b, pStart, plen)
            } else if (proto == 17) {
                val sp = u16(b, ihl); val dp = u16(b, ihl + 2)
                val pStart = ihl + 8; val plen = (u16(b, ihl + 4) - 8).coerceIn(0, n - pStart)
                val key = Key(src, sp, dst, dp)
                var u = udps[key]
                if (u == null) {
                    val uid = owner(OsConstants.IPPROTO_UDP, key)
                    if (blocked(uid)) return
                    u = Udp(key, uid); if (!u.open()) return
                    udps[key] = u
                    val uu = u; pool.execute { uu.readLoop() }
                }
                u.send(b, pStart, plen)
            }
        }

        // ---------------------------------------------------------------- UDP
        inner class Udp(val key: Key, val uid: Int) {
            @Volatile var last = System.currentTimeMillis()
            var s: DatagramSocket? = null
            fun open(): Boolean = try {
                val d = DatagramSocket(); protect(d); d.connect(InetSocketAddress(addr(key.dst), key.dp))
                d.soTimeout = if (key.dp == 53) 8000 else 30000; s = d; true
            } catch (_: Exception) { false }
            fun send(b: ByteArray, off: Int, len: Int) {
                last = System.currentTimeMillis()
                if (blocked(uid)) return
                val bk = bucketsFor(uid)
                if (bk != null && !bk.up.tryTake(len)) return           // over the limit: drop (UDP)
                count(uid, len, false)
                try { s?.send(DatagramPacket(b, off, len)) } catch (_: Exception) {}
            }
            fun readLoop() {
                val buf = ByteArray(65535)
                try {
                    while (alive) {
                        val p = DatagramPacket(buf, buf.size); s!!.receive(p); last = System.currentTimeMillis()
                        if (blocked(uid)) continue
                        val bk = bucketsFor(uid)
                        if (bk != null) { val w = bk.down.reserve(p.length); if (w > 0) Thread.sleep(w.coerceAtMost(2000)) }
                        count(uid, p.length, true)
                        write(udpPacket(key.dst, key.src, key.dp, key.sp, buf, p.length))
                    }
                } catch (_: Exception) {}
                close(); udps.remove(key, this)
            }
            fun close() { try { s?.close() } catch (_: Exception) {} }
        }

        // ---------------------------------------------------------------- TCP
        inner class Tcp(val key: Key, val uid: Int, clientIsn: Int, synWin: Int) {
            @Volatile var last = System.currentTimeMillis()
            @Volatile var cliAck = 0
            @Volatile var cliWin = synWin.coerceAtLeast(1024)
            @Volatile var rcvNext = clientIsn + 1          // next client byte we expect
            @Volatile var ackSent = clientIsn + 1          // client bytes written to the server and acknowledged
            @Volatile var serverSeq = 0
            @Volatile var ready = false
            @Volatile var weFin = false
            @Volatile var theyFin = false
            @Volatile var closed = false
            var sock: Socket? = null
            val q = LinkedBlockingQueue<ByteArray>()
            val FIN = ByteArray(0)

            fun pkt(flags: Int, data: ByteArray?, off: Int, len: Int, seq: Int = serverSeq, ack: Int = ackSent) {
                val win = (65535 - (rcvNext - ackSent).coerceIn(0, 60000))
                write(tcpPacket(key.dst, key.src, key.dp, key.sp, seq, ack, flags, win, data, off, len, false))
            }

            fun connect() {
                try {
                    val s = Socket(); protect(s); s.tcpNoDelay = true
                    s.connect(InetSocketAddress(addr(key.dst), key.dp), 10000)
                    sock = s
                    val isn = (System.nanoTime() and 0x7fffffff).toInt()
                    serverSeq = isn
                    write(tcpPacket(key.dst, key.src, key.dp, key.sp, isn, rcvNext, 2 or 16, 65535, null, 0, 0, true))
                    serverSeq = isn + 1; cliAck = serverSeq; ready = true
                    pool.execute { writer() }
                    reader()
                } catch (_: Exception) {
                    if (!ready) write(tcpPacket(key.dst, key.src, key.dp, key.sp, 0, rcvNext, 4 or 16, 0, null, 0, 0, false))
                    kill()
                }
            }

            fun onPacket(fl: Int, seq: Int, ack: Int, win: Int, b: ByteArray, off: Int, len: Int) {
                last = System.currentTimeMillis()
                if (fl and 4 != 0) { kill(); return }
                if (!ready) return
                if (fl and 16 != 0 && (ack - cliAck) > 0) cliAck = ack
                cliWin = win.coerceAtLeast(1)
                if (len == 0 && fl and 1 == 0) return
                if (seq != rcvNext) { pkt(16, null, 0, 0); return }       // retransmit / out of order: re-ACK
                if (len > 0) { q.add(b.copyOfRange(off, off + len)); rcvNext += len }
                if (fl and 1 != 0) { rcvNext += 1; q.add(FIN) }
            }

            /** client -> server, speed limited. ACK is sent after the data is written, so the app slows down. */
            fun writer() {
                try {
                    val o = sock!!.getOutputStream()
                    while (!closed) {
                        val d = q.take()
                        if (d === FIN) { try { sock!!.shutdownOutput() } catch (_: Exception) {}; ackSent += 1; theyFin = true; pkt(16, null, 0, 0); maybeClose(); break }
                        val bk = bucketsFor(uid)
                        if (bk != null) { val w = bk.up.reserve(d.size); if (w > 0) Thread.sleep(w) }
                        count(uid, d.size, false)
                        o.write(d); ackSent += d.size; pkt(16, null, 0, 0)
                    }
                } catch (_: Exception) { rst() }
            }

            /** server -> client, speed limited. */
            fun reader() {
                val buf = ByteArray(1360)
                try {
                    val i = sock!!.getInputStream()
                    while (!closed) {
                        while (!closed && (serverSeq - cliAck) >= cliWin) Thread.sleep(3)
                        val n = i.read(buf)
                        if (n < 0) { weFin = true; pkt(1 or 16, null, 0, 0); serverSeq += 1; maybeClose(); return }
                        val bk = bucketsFor(uid)
                        if (bk != null) { val w = bk.down.reserve(n); if (w > 0) Thread.sleep(w) }
                        count(uid, n, true)
                        last = System.currentTimeMillis()
                        pkt(8 or 16, buf, 0, n); serverSeq += n
                    }
                } catch (_: Exception) { if (!closed) rst() }
            }

            fun maybeClose() { if (weFin && theyFin) kill() }
            fun rst() { try { pkt(4 or 16, null, 0, 0) } catch (_: Exception) {}; kill() }
            fun close() { closed = true; try { sock?.close() } catch (_: Exception) {}; q.add(FIN) }
            fun kill() { close(); tcps.remove(key, this) }
        }
    }

    // ===================================================================================  packet helpers
    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    private fun i32(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 24) or ((b[o + 1].toInt() and 255) shl 16) or ((b[o + 2].toInt() and 255) shl 8) or (b[o + 3].toInt() and 255)
    private fun p16(b: ByteArray, o: Int, v: Int) { b[o] = (v ushr 8).toByte(); b[o + 1] = v.toByte() }
    private fun p32(b: ByteArray, o: Int, v: Int) { b[o] = (v ushr 24).toByte(); b[o + 1] = (v ushr 16).toByte(); b[o + 2] = (v ushr 8).toByte(); b[o + 3] = v.toByte() }
    private fun addr(v: Int): InetAddress = InetAddress.getByAddress(byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte()))

    private fun sum(b: ByteArray, off: Int, len: Int, init: Long): Long {
        var s = init; var i = off; val end = off + len
        while (i + 1 < end) { s += ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255); i += 2 }
        if (i < end) s += (b[i].toInt() and 255) shl 8
        return s
    }
    private fun fold(s0: Long): Int { var s = s0; while ((s ushr 16) != 0L) s = (s and 0xffff) + (s ushr 16); return (s.inv() and 0xffff).toInt() }
    private fun pseudo(src: Int, dst: Int, proto: Int, len: Int): Long =
        ((src ushr 16) and 0xffff).toLong() + (src and 0xffff) + ((dst ushr 16) and 0xffff) + (dst and 0xffff) + proto + len

    private fun ipHeader(p: ByteArray, total: Int, proto: Int, src: Int, dst: Int) {
        p[0] = 0x45; p16(p, 2, total); p[6] = 0x40; p[8] = 64; p[9] = proto.toByte(); p32(p, 12, src); p32(p, 16, dst)
        p16(p, 10, fold(sum(p, 0, 20, 0)))
    }

    private fun tcpPacket(src: Int, dst: Int, sp: Int, dp: Int, seq: Int, ack: Int, flags: Int, win: Int,
                          data: ByteArray?, off: Int, len: Int, mss: Boolean): ByteArray {
        val opt = if (mss) 4 else 0
        val tl = 20 + opt + len; val total = 20 + tl
        val p = ByteArray(total)
        ipHeader(p, total, 6, src, dst)
        p16(p, 20, sp); p16(p, 22, dp); p32(p, 24, seq); p32(p, 28, ack)
        p[32] = ((5 + opt / 4) shl 4).toByte(); p[33] = flags.toByte(); p16(p, 34, win)
        if (mss) { p[40] = 2; p[41] = 4; p16(p, 42, 1360) }
        if (data != null && len > 0) System.arraycopy(data, off, p, 40 + opt, len)
        p16(p, 36, fold(sum(p, 20, tl, pseudo(src, dst, 6, tl))))
        return p
    }

    private fun udpPacket(src: Int, dst: Int, sp: Int, dp: Int, data: ByteArray, len: Int): ByteArray {
        val ul = 8 + len; val total = 20 + ul
        val p = ByteArray(total)
        ipHeader(p, total, 17, src, dst)
        p16(p, 20, sp); p16(p, 22, dp); p16(p, 24, ul)
        System.arraycopy(data, 0, p, 28, len)
        var c = fold(sum(p, 20, ul, pseudo(src, dst, 17, ul))); if (c == 0) c = 0xffff
        p16(p, 26, c)
        return p
    }
}
