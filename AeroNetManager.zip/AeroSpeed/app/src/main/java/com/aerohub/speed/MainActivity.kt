package com.aerohub.speed

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private class App(val pkg: String, val label: String)

    private var apps: List<App> = emptyList()
    private var shown: List<App> = emptyList()
    private lateinit var status: TextView
    private lateinit var dlTv: TextView
    private lateinit var ulTv: TextView
    private lateinit var todayTv: TextView
    private lateinit var dot: View
    private val profiles = mutableListOf<Pair<TextView, Long>>()
    private lateinit var connectBtn: Button
    private lateinit var vpnSwitch: Switch
    private lateinit var hideSwitch: Switch
    private lateinit var nightSwitch: Switch
    private lateinit var nightBtn: Button
    private lateinit var defBtn: Button
    private lateinit var sortBtn: Button
    private lateinit var list: ListView
    // ListView wraps the adapter in a HeaderViewListAdapter, so keep our own reference instead of casting list.adapter
    private val appAdapter: BaseAdapter by lazy { makeAdapter() }
    private var query = ""
    private var sortByUsage = false
    private val REQ_AERO = 1
    private val REQ_VPN = 2
    private val ui = Handler(Looper.getMainLooper())
    private var pd = 0L; private var pu = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    private val INK = 0xFF111827.toInt(); private val SUB = 0xFF6B7280.toInt(); private val BLUE = 0xFF2563EB.toInt()
    private fun round(color: Int, r: Int = 12) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun card(title: String? = null) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); background = round(Color.WHITE, 16)
        if (title != null) addView(TextView(context).apply { text = title.uppercase(); textSize = 11f; letterSpacing = 0.08f; setTextColor(SUB); setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, dp(6)) })
    }
    private fun gap(h: Int) = View(this).also { it.layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun chip(t: String, bg: Int, fg: Int) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(fg); background = round(bg, 8); setPadding(dp(7), dp(2), dp(7), dp(2)); setTypeface(null, Typeface.BOLD)
    }
    private fun pillBtn(b: TextView, filled: Boolean = false) = b.apply {
        isAllCaps = false; textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(14), dp(8)); minHeight = 0; minimumHeight = 0
        setTextColor(if (filled) Color.WHITE else INK); background = round(if (filled) BLUE else 0xFFF3F4F6.toInt(), 20)
        (this as? Button)?.stateListAnimator = null
    }
    private fun textBtn(t: String, onClick: () -> Unit) = pillBtn(Button(this).apply { text = t; setOnClickListener { onClick() } })
    private fun switchRow(title: String, sub: String, sw: Switch) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6))
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = title; textSize = 16f; setTextColor(INK) })
            addView(TextView(context).apply { text = sub; textSize = 12f; setTextColor(SUB) }) }
        addView(col, LinearLayout.LayoutParams(0, -2, 1f)); addView(sw)
    }
    private fun stat(label: String, v: TextView, tint: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); background = round(tint, 12)
        addView(TextView(context).apply { text = label; textSize = 11f; setTextColor(SUB) })
        addView(v.apply { textSize = 16f; setTextColor(INK); setTypeface(null, Typeface.BOLD); text = "0 B" })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Stats.load(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF3F4F6.toInt()); setPadding(dp(12), dp(32), dp(12), 0) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---- title + connection status
        dot = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF9CA3AF.toInt()) } }
        status = TextView(this).apply { textSize = 12f; setTextColor(SUB) }
        connectBtn = Button(this).apply { text = "Connect"; setOnClickListener { connectAero() } }; pillBtn(connectBtn, true)
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(6) }); st.addView(status, LinearLayout.LayoutParams(0, -2, 1f)); st.addView(connectBtn)
        header.addView(TextView(this).apply { text = "Aero Net Manager"; textSize = 24f; setTextColor(INK); setTypeface(null, Typeface.BOLD); setPadding(dp(4), 0, 0, dp(4)) })
        header.addView(st, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dp(4); bottomMargin = dp(8) })

        // ---- control card
        val c1 = card()
        vpnSwitch = Switch(this).apply { setOnClickListener { toggleVpn(isChecked) } }
        hideSwitch = Switch(this).apply { setOnClickListener { toggleHide(isChecked) } }
        c1.addView(switchRow("Internet control", "Local VPN that applies your rules", vpnSwitch))
        c1.addView(switchRow("Hide VPN icon", "Removes the key icon from the status bar", hideSwitch))
        dlTv = TextView(this); ulTv = TextView(this); todayTv = TextView(this)
        val tiles = LinearLayout(this).apply { setPadding(0, dp(8), 0, 0) }
        tiles.addView(stat("DOWNLOAD", dlTv, 0xFFEFF6FF.toInt()), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        tiles.addView(stat("UPLOAD", ulTv, 0xFFF0FDF4.toInt()), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        tiles.addView(stat("TODAY", todayTv, 0xFFFFF7ED.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
        c1.addView(tiles)
        header.addView(c1, LinearLayout.LayoutParams(-1, -2))

        // ---- all apps card
        header.addView(gap(10))
        val c2 = card("All other apps")
        defBtn = Button(this).apply { setOnClickListener { pick("All other apps", false) { v -> Rules.setDefault(this@MainActivity, v); refresh(); reloadVpn() } } }; pillBtn(defBtn)
        val dr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dr.addView(TextView(this).apply { text = "Speed limit"; textSize = 16f; setTextColor(INK) }, LinearLayout.LayoutParams(0, -2, 1f)); dr.addView(defBtn)
        c2.addView(dr)
        val pr = LinearLayout(this).apply { setPadding(0, dp(10), 0, dp(4)) }
        for ((name, v) in listOf("Normal" to Rules.UNLIMITED, "Save data" to 100L, "Block others" to Rules.BLOCK)) {
            val t = pillBtn(TextView(this).apply { text = name; setOnClickListener { Rules.setDefault(this@MainActivity, v); refresh(); reloadVpn() } })
            profiles += t to v
            pr.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        }
        c2.addView(pr)
        nightSwitch = Switch(this).apply { setOnClickListener { Rules.setNight(this@MainActivity, isChecked); refresh(); reloadVpn() } }
        nightBtn = Button(this).apply { setOnClickListener { nightDialog() } }; pillBtn(nightBtn)
        c2.addView(switchRow("Night schedule", "Limit or block at set hours", nightSwitch))
        c2.addView(nightBtn, LinearLayout.LayoutParams(-1, -2))
        val c2b = LinearLayout(this).apply { setPadding(0, dp(10), 0, 0) }
        c2b.addView(textBtn("Reset today's usage") { Stats.today.clear(); Stats.save(this); filter(); refresh() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        c2b.addView(textBtn("Reset all rules") {
            AlertDialog.Builder(this).setMessage("Remove every rule?").setPositiveButton("Reset") { _, _ -> Rules.resetAll(this); refresh(); reloadVpn() }.setNegativeButton("Cancel", null).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        c2.addView(c2b)
        header.addView(c2, LinearLayout.LayoutParams(-1, -2))

        // ---- search + sort
        sortBtn = Button(this).apply { setOnClickListener { sortByUsage = !sortByUsage; filter() } }; pillBtn(sortBtn)
        val search = EditText(this).apply {
            hint = "Search apps"; setSingleLine(); textSize = 14f; background = round(Color.WHITE, 20); setPadding(dp(16), dp(8), dp(16), dp(8))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s.toString().trim().lowercase(); filter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sr.addView(search, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) }); sr.addView(sortBtn)
        header.addView(sr, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(6) })

        list = ListView(this).apply { divider = null; selector = ColorDrawable(Color.TRANSPARENT); clipToPadding = false; setPadding(0, 0, 0, dp(16)); addHeaderView(header, null, false); adapter = appAdapter }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        thread {
            val pm = packageManager
            val l = pm.getInstalledApplications(0).filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { App(it.packageName, it.loadLabel(pm).toString()) }
            runOnUiThread { apps = l; filter() }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val d = Stats.down.get(); val u = Stats.up.get()
            val on = SpeedVpnService.running
            dlTv.text = if (on) "${Stats.fmt(d - pd)}/s" else "-"
            ulTv.text = if (on) "${Stats.fmt(u - pu)}/s" else "-"
            todayTv.text = Stats.fmt(Stats.today.values.sumOf { it.get() })
            pd = d; pu = u
            if (on != vpnSwitch.isChecked) vpnSwitch.isChecked = on
            if (on && ((System.currentTimeMillis() / 1000) % 5L == 0L)) appAdapter.notifyDataSetChanged()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onResume() { super.onResume(); refresh(); pd = Stats.down.get(); pu = Stats.up.get(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun filter() {
        var l = if (query.isEmpty()) apps else apps.filter { it.label.lowercase().contains(query) || it.pkg.contains(query) }
        l = if (sortByUsage) l.sortedByDescending { Stats.usage(it.pkg) } else l.sortedBy { it.label.lowercase() }
        shown = l
        sortBtn.text = if (sortByUsage) "Most used" else "A-Z"
        appAdapter.notifyDataSetChanged()
    }

    private fun refresh() {
        val t = Rules.token(this)
        status.text = if (t == null) "AeroHUB not connected" else "AeroHUB connected"
        (dot.background as GradientDrawable).setColor(if (t == null) 0xFF9CA3AF.toInt() else 0xFF22C55E.toInt())
        val dv = Rules.default(this)
        for ((tv, v) in profiles) { val on = v == dv; tv.background = round(if (on) BLUE else 0xFFF3F4F6.toInt(), 20); tv.setTextColor(if (on) Color.WHITE else INK) }
        connectBtn.visibility = if (t == null) View.VISIBLE else View.GONE
        vpnSwitch.isChecked = SpeedVpnService.running
        hideSwitch.isChecked = Rules.hideIcon(this)
        defBtn.text = Rules.label(Rules.default(this))
        nightSwitch.isChecked = Rules.nightOn(this)
        nightBtn.text = "${Rules.hm(Rules.nightStart(this))} - ${Rules.hm(Rules.nightEnd(this))}  •  ${Rules.label(Rules.nightLimit(this))}"
        nightBtn.alpha = if (Rules.nightOn(this)) 1f else 0.5f
        appAdapter.notifyDataSetChanged()
        if (t != null) thread { if (MyKuzu.ping(t) == null) runOnUiThread { status.text = "AeroHUB server is off. Start it in AeroHUB"; (dot.background as GradientDrawable).setColor(0xFFEF4444.toInt()) } }
    }

    // ---- AeroHUB permission
    private fun connectAero() {
        try { startActivityForResult(Intent(MyKuzu.ACTION_REQUEST).setPackage("com.example.mykuzu"), REQ_AERO) }
        catch (e: Exception) { toast("AeroHUB is not installed") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_AERO) {
            if (res == RESULT_OK) { Rules.setToken(this, data?.getStringExtra("token")); refresh() } else toast("AeroHUB access was denied")
        } else if (req == REQ_VPN) {
            if (res == RESULT_OK) startVpn() else { vpnSwitch.isChecked = false; toast("VPN permission denied") }
        }
    }

    // ---- VPN
    private fun toggleVpn(on: Boolean) {
        if (!on) { startService(Intent(this, SpeedVpnService::class.java).setAction(SpeedVpnService.ACT_STOP)); return }
        val t = Rules.token(this)
        thread {
            if (t != null) Hide.allowVpn(t, packageName)            // skips the system VPN dialog
            runOnUiThread {
                val i = VpnService.prepare(this)
                if (i != null) startActivityForResult(i, REQ_VPN) else startVpn()
            }
        }
    }

    private fun startVpn() {
        startService(Intent(this, SpeedVpnService::class.java).setAction(SpeedVpnService.ACT_START))
        val t = Rules.token(this)
        if (t != null && Rules.hideIcon(this)) thread { Hide.statusIcon(t, true) }
        vpnSwitch.postDelayed({ refresh() }, 600)
    }

    /** rules changed: rebuild the VPN so that the new rules apply */
    private fun reloadVpn() { if (SpeedVpnService.running) startVpn() }

    private fun toggleHide(on: Boolean) {
        val t = Rules.token(this)
        if (t == null) { hideSwitch.isChecked = false; toast("Connect AeroHUB first"); return }
        Rules.setHideIcon(this, on)
        thread { val ok = Hide.statusIcon(t, on); toast(if (ok) (if (on) "VPN icon hidden" else "VPN icon shown") else "Failed. Is the AeroHUB server running?") }
    }

    // ---- pickers
    private fun pick(title: String, includeDefault: Boolean, done: (Long) -> Unit) {
        val items = mutableListOf<Pair<String, Long>>()
        if (includeDefault) items += "Same as others" to Rules.DEFAULT
        items += listOf("Unlimited (full speed)" to Rules.UNLIMITED, "Block internet" to Rules.BLOCK,
            "50 KB/s" to 50L, "100 KB/s" to 100L, "250 KB/s" to 250L, "500 KB/s" to 500L, "1 MB/s" to 1000L, "2 MB/s" to 2000L, "5 MB/s" to 5000L)
        val names = items.map { it.first } + "Custom KB/s..."
        AlertDialog.Builder(this).setTitle(title).setItems(names.toTypedArray()) { _, i ->
            if (i < items.size) done(items[i].second) else number("Custom speed", "KB/s (1 MB/s = 1000)") { done(it) }
        }.show()
    }

    private fun number(title: String, hint: String, done: (Long) -> Unit) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; this.hint = hint }
        AlertDialog.Builder(this).setTitle(title).setView(et).setPositiveButton("OK") { _, _ ->
            et.text.toString().toLongOrNull()?.takeIf { it > 0 }?.let(done)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun nightDialog() {
        val s0 = Rules.nightStart(this); val e0 = Rules.nightEnd(this)
        TimePickerDialog(this, { _, h, m ->
            val st = h * 60 + m
            TimePickerDialog(this, { _, h2, m2 ->
                val en = h2 * 60 + m2
                pick("During the night", false) { v ->
                    Rules.setNight(this, true, st, en, v); refresh(); reloadVpn()
                }
            }, e0 / 60, e0 % 60, true).apply { setTitle("Night ends at") }.show()
        }, s0 / 60, s0 % 60, true).apply { setTitle("Night starts at") }.show()
    }

    // ---- one app, all its controls
    private fun detail(a: App) {
        val c = this
        val lim = Rules.get(c, a.pkg); val net = Rules.net(c, a.pkg); val q = Rules.quota(c, a.pkg); val bg = Rules.bgBlocked(c, a.pkg)
        val items = arrayOf(
            "Speed limit: ${Rules.label(lim)}",
            "Network: ${Rules.netLabel(net)}",
            "Daily data quota: ${if (q == 0L) "Off" else if (q >= 1000) "${q / 1000.0} GB" else "$q MB"}",
            "Background data: ${if (bg) "Blocked" else "Allowed"}",
            "Used today: ${Stats.fmt(Stats.usage(a.pkg))}  (tap to reset)",
            "Force stop this app",
            "Reset this app's rules"
        )
        fun again() { filter(); detail(a); reloadVpn() }
        AlertDialog.Builder(c).setTitle(a.label).setItems(items) { _, i ->
            when (i) {
                0 -> pick(a.label, true) { Rules.set(c, a.pkg, it); again() }
                1 -> AlertDialog.Builder(c).setTitle("Allowed network").setItems(arrayOf("Wi-Fi + Mobile", "Wi-Fi only", "Mobile data only")) { _, k -> Rules.setNet(c, a.pkg, k); again() }.show()
                2 -> {
                    val opts = listOf("Off" to 0L, "50 MB" to 50L, "100 MB" to 100L, "500 MB" to 500L, "1 GB" to 1000L, "2 GB" to 2000L, "5 GB" to 5000L)
                    AlertDialog.Builder(c).setTitle("Daily quota (resets at midnight)").setItems((opts.map { it.first } + "Custom MB...").toTypedArray()) { _, k ->
                        if (k < opts.size) { Rules.setQuota(c, a.pkg, opts[k].second); again() } else number("Custom quota", "MB per day") { Rules.setQuota(c, a.pkg, it); again() }
                    }.show()
                }
                3 -> {
                    val t = Rules.token(c)
                    val uid = try { packageManager.getApplicationInfo(a.pkg, 0).uid } catch (_: Exception) { -1 }
                    if (t == null) toast("Connect AeroHUB first") else thread {
                        val ok = Hide.background(t, uid, !bg)
                        if (ok) Rules.setBgBlocked(c, a.pkg, !bg)
                        toast(if (ok) (if (!bg) "Background data blocked" else "Background data allowed") else "Failed. Is the AeroHUB server running?")
                        runOnUiThread { filter(); detail(a) }
                    }
                }
                4 -> { Stats.reset(c, a.pkg); again() }
                5 -> { val t = Rules.token(c); if (t == null) toast("Connect AeroHUB first") else thread { try { MyKuzu.forceStop(t, a.pkg); toast("Stopped ${a.label}") } catch (_: Exception) { toast("Failed") } } }
                6 -> {
                    if (bg) Rules.token(c)?.let { t -> thread { Hide.background(t, try { packageManager.getApplicationInfo(a.pkg, 0).uid } catch (_: Exception) { -1 }, false) } }
                    Rules.resetApp(c, a.pkg); again()
                }
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun chips(a: App): List<TextView> {
        val l = mutableListOf<TextView>()
        val lim = Rules.get(this, a.pkg)
        when {
            lim == Rules.BLOCK -> l += chip("Blocked", 0xFFFEE2E2.toInt(), 0xFFB91C1C.toInt())
            lim == Rules.UNLIMITED -> l += chip("Unlimited", 0xFFDCFCE7.toInt(), 0xFF15803D.toInt())
            lim > 0 -> l += chip(Rules.label(lim), 0xFFDBEAFE.toInt(), 0xFF1D4ED8.toInt())
        }
        val n = Rules.net(this, a.pkg); if (n == 1) l += chip("Wi-Fi only", 0xFFF3E8FF.toInt(), 0xFF7E22CE.toInt()); if (n == 2) l += chip("Mobile only", 0xFFF3E8FF.toInt(), 0xFF7E22CE.toInt())
        val q = Rules.quota(this, a.pkg); if (q > 0) l += chip("Quota ${if (q >= 1000) "${q / 1000.0} GB" else "$q MB"}", 0xFFFEF3C7.toInt(), 0xFFB45309.toInt())
        if (Rules.bgBlocked(this, a.pkg)) l += chip("No background", 0xFFF3F4F6.toInt(), 0xFF374151.toInt())
        return l
    }

    private fun makeAdapter() = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val a = shown[p]
            val row = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = round(Color.WHITE, 14)
                setOnClickListener { detail(a) }
            }
            val ic = ImageView(this@MainActivity).apply { try { setImageDrawable(packageManager.getApplicationIcon(a.pkg)) } catch (_: Exception) {} }
            row.addView(ic, LinearLayout.LayoutParams(dp(42), dp(42)))
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
            col.addView(TextView(this@MainActivity).apply { text = a.label; textSize = 15f; setTextColor(INK); setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END })
            val cs = chips(a)
            if (cs.isNotEmpty()) {
                val cr = LinearLayout(this@MainActivity).apply { setPadding(0, dp(4), 0, 0) }
                for (c in cs.take(3)) cr.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
                col.addView(cr)
            }
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            val u = Stats.usage(a.pkg)
            row.addView(TextView(this@MainActivity).apply { text = if (u > 0) Stats.fmt(u) else ""; textSize = 12f; setTextColor(SUB) })
            val w = FrameLayout(this@MainActivity); w.setPadding(0, dp(3), 0, dp(3)); w.addView(row)
            return w
        }
    }
}
