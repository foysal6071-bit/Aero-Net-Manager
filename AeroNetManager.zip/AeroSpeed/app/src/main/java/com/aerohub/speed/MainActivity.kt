package com.aerohub.speed

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private class App(val pkg: String, val label: String)

    private var apps: List<App> = emptyList()
    private var shown: List<App> = emptyList()
    private lateinit var status: TextView
    private lateinit var dlTv: TextView
    private lateinit var ulTv: TextView
    private lateinit var todayTv: TextView
    private lateinit var dot: View
    private val profiles = mutableListOf<Pair<TextView, Long>>()
    private lateinit var connectBtn: TextView
    private lateinit var vpnSwitch: Switch
    private lateinit var hideSwitch: Switch
    private lateinit var nightSwitch: Switch
    private lateinit var nightBtn: TextView
    private lateinit var defBtn: TextView
    private lateinit var sortBtn: TextView
    private lateinit var appsTitle: TextView
    private lateinit var emptyTv: TextView
    private lateinit var list: ListView
    // ListView wraps the adapter in a HeaderViewListAdapter, so keep our own reference instead of casting list.adapter
    private val appAdapter: BaseAdapter by lazy { makeAdapter() }
    private var query = ""
    private var sortByUsage = false
    private val REQ_AERO = 1
    private val REQ_VPN = 2
    private val ui = Handler(Looper.getMainLooper())
    private var pd = 0L; private var pu = 0L

    // ---- design tokens
    private val NAVY1 = 0xFF0A1226.toInt(); private val NAVY2 = 0xFF1E2370.toInt()
    private val BG = 0xFFF3F5FA.toInt(); private val LINE = 0xFFE5E9F0.toInt(); private val PILL = 0xFFEEF2F7.toInt()
    private val INK = 0xFF0F172A.toInt(); private val SUB = 0xFF64748B.toInt()
    private val BLUE = 0xFF2563EB.toInt(); private val GREEN = 0xFF22C55E.toInt(); private val RED = 0xFFEF4444.toInt()
    private val DANGER = 0xFFDC2626.toInt(); private val GRAY = 0xFF9CA3AF.toInt()
    private val SOFT = 0xB3FFFFFF.toInt(); private val TILE = 0x24FFFFFF.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    // ---- small view helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun round(color: Int, r: Int = 12, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun ripple(base: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(0x22000000), base, null)

    private fun lpw() = LinearLayout.LayoutParams(0, WRAP, 1f)

    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun pill(label: String = ""): TextView = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(14), dp(8))
        setTypeface(null, Typeface.BOLD); setTextColor(INK); background = ripple(round(PILL, 20))
    }

    private fun outlineBtn(label: String, danger: Boolean = false, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(10), dp(12), dp(10), dp(12))
        setTypeface(null, Typeface.BOLD); setTextColor(if (danger) DANGER else INK)
        background = ripple(round(Color.WHITE, 14, if (danger) 0xFFFECACA.toInt() else 0xFFD5DBE5.toInt()))
        setOnClickListener { onClick() }
    }

    private fun filledBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(10), dp(13), dp(10), dp(13))
        setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); background = ripple(round(BLUE, 14))
        setOnClickListener { onClick() }
    }

    private fun styled(s: Switch, on: Int = BLUE): Switch {
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, 0xFFF8FAFC.toInt()))
        s.trackTintList = ColorStateList(st, intArrayOf(on, 0xFFCBD5E1.toInt()))
        return s
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(4)); background = round(Color.WHITE, 18, LINE)
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(LINE); layoutParams = LinearLayout.LayoutParams(MATCH, dp(1))
    }

    private fun section(t: String): TextView = txt(t.uppercase(), 11f, SUB, true).apply {
        letterSpacing = 0.08f; setPadding(dp(6), dp(18), 0, dp(8))
    }

    /** one settings row: title (+ optional small text) on the left, any view on the right */
    private fun row(title: String, sub: String?, right: View?, onClick: (() -> Unit)? = null): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(13), 0, dp(13))
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(txt(title, 15f, INK))
            if (sub != null) addView(txt(sub, 12f, SUB).apply { setPadding(0, dp(2), dp(8), 0) })
        }
        addView(col, lpw())
        if (right != null) addView(right)
        if (onClick != null) { background = ripple(round(Color.TRANSPARENT, 8)); setOnClickListener { onClick() } }
    }

    private fun stat(label: String, v: TextView): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = round(TILE, 14)
        addView(txt(label, 10f, SOFT).apply { letterSpacing = 0.08f })
        addView(v.apply { textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); text = "-"; setPadding(0, dp(2), 0, 0) })
    }

    private fun quotaLabel(q: Long) = if (q <= 0L) "Off" else if (q >= 1000) "${q / 1000.0} GB" else "$q MB"

    @Suppress("DEPRECATION")
    private fun styleBars() {
        window.statusBarColor = NAVY1
        window.navigationBarColor = BG
        val f = window.decorView.systemUiVisibility
        window.decorView.systemUiVisibility = (f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()) or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Stats.load(this)
        styleBars()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ================= HERO: title, connection, main switch, live numbers =================
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(22))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(NAVY1, NAVY2)).apply {
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat())
            }
        }
        dot = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GRAY) } }
        status = txt("", 12f, SOFT)
        connectBtn = pill("Connect").apply {
            setTextColor(NAVY2); background = ripple(round(Color.WHITE, 20)); setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { connectAero() }
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(txt("Aero Net Manager", 22f, Color.WHITE, true))
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, 0) }
        st.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(6) })
        st.addView(status)
        titleCol.addView(st)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(titleCol, lpw()); top.addView(connectBtn)
        hero.addView(top)

        vpnSwitch = styled(Switch(this), GREEN).apply { setOnClickListener { toggleVpn(isChecked) } }
        val ctl = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(12), dp(12)); background = round(TILE, 18)
        }
        val ctlCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(txt("Internet control", 16f, Color.WHITE, true))
            addView(txt("Local VPN that applies your rules", 12f, SOFT).apply { setPadding(0, dp(2), 0, 0) })
        }
        ctl.addView(ctlCol, lpw()); ctl.addView(vpnSwitch)
        hero.addView(ctl, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })

        dlTv = TextView(this); ulTv = TextView(this); todayTv = TextView(this)
        val tiles = LinearLayout(this)
        tiles.addView(stat("DOWNLOAD", dlTv), lpw().apply { rightMargin = dp(8) })
        tiles.addView(stat("UPLOAD", ulTv), lpw().apply { rightMargin = dp(8) })
        tiles.addView(stat("TODAY", todayTv), lpw())
        hero.addView(tiles, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        header.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP))

        // ================= BODY =================
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(4)) }

        // ---- quick profiles (segmented control)
        body.addView(section("Quick profile"))
        val seg = LinearLayout(this).apply { background = round(0xFFE4E9F1.toInt(), 16); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        for ((name, v) in listOf("Normal" to Rules.UNLIMITED, "Save data" to 100L, "Block others" to Rules.BLOCK)) {
            val t = TextView(this).apply {
                text = name; textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); setTypeface(null, Typeface.BOLD)
                setOnClickListener { Rules.setDefault(this@MainActivity, v); refresh(); reloadVpn() }
            }
            profiles += t to v
            seg.addView(t, lpw())
        }
        body.addView(seg, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- rules card
        body.addView(section("Rules"))
        val rules = card()
        defBtn = pill()
        defBtn.setOnClickListener { pick("All other apps", false) { v -> Rules.setDefault(this@MainActivity, v); refresh(); reloadVpn() } }
        rules.addView(row("All other apps", "Speed limit for apps without their own rule", defBtn))
        rules.addView(divider())
        nightSwitch = styled(Switch(this)).apply { setOnClickListener { Rules.setNight(this@MainActivity, isChecked); refresh(); reloadVpn() } }
        rules.addView(row("Night schedule", "Limit or block at set hours", nightSwitch))
        nightBtn = pill()
        nightBtn.setOnClickListener { nightDialog() }
        rules.addView(row("Night hours", "Tap to change", nightBtn))
        rules.addView(divider())
        hideSwitch = styled(Switch(this)).apply { setOnClickListener { toggleHide(isChecked) } }
        rules.addView(row("Hide VPN icon", "Removes the key icon from the status bar", hideSwitch))
        body.addView(rules, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- maintenance buttons
        val mr = LinearLayout(this)
        mr.addView(outlineBtn("Reset today's usage") {
            Stats.today.clear(); Stats.save(this@MainActivity); filter(); refresh()
        }, lpw().apply { rightMargin = dp(8) })
        mr.addView(outlineBtn("Reset all rules", true) {
            AlertDialog.Builder(this@MainActivity).setMessage("Remove every rule?")
                .setPositiveButton("Reset") { _, _ -> Rules.resetAll(this@MainActivity); refresh(); reloadVpn() }
                .setNegativeButton("Cancel", null).show()
        }, lpw())
        body.addView(mr, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        // ---- apps header, search, sort
        appsTitle = section("Apps")
        sortBtn = pill("A-Z").apply {
            textSize = 12f; setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { sortByUsage = !sortByUsage; filter() }
        }
        val ar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        ar.addView(appsTitle, lpw()); ar.addView(sortBtn)
        body.addView(ar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })

        val search = EditText(this).apply {
            hint = "Search apps"; setSingleLine(); textSize = 14f; setTextColor(INK); setHintTextColor(SUB)
            background = round(Color.WHITE, 22, LINE); setPadding(dp(18), dp(11), dp(18), dp(11))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s.toString().trim().lowercase(); filter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        body.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) })
        emptyTv = txt("Loading apps…", 13f, SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(28), 0, dp(28)) }
        body.addView(emptyTv, LinearLayout.LayoutParams(MATCH, WRAP))
        header.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        list = ListView(this).apply {
            divider = null; dividerHeight = 0; selector = ColorDrawable(Color.TRANSPARENT); clipToPadding = false
            setPadding(0, 0, 0, dp(24)); isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            addHeaderView(header, null, false); adapter = appAdapter
        }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        thread {
            val pm = packageManager
            val l = pm.getInstalledApplications(0).filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { App(it.packageName, it.loadLabel(pm).toString()) }
            runOnUiThread { apps = l; filter() }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val d = Stats.down.get(); val u = Stats.up.get()
            val on = SpeedVpnService.running
            dlTv.text = if (on) "${Stats.fmt(d - pd)}/s" else "-"
            ulTv.text = if (on) "${Stats.fmt(u - pu)}/s" else "-"
            todayTv.text = Stats.fmt(Stats.today.values.sumOf { it.get() })
            pd = d; pu = u
            if (on != vpnSwitch.isChecked) vpnSwitch.isChecked = on
            if (on && ((System.currentTimeMillis() / 1000) % 5L == 0L)) appAdapter.notifyDataSetChanged()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onResume() { super.onResume(); refresh(); pd = Stats.down.get(); pu = Stats.up.get(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun filter() {
        var l = if (query.isEmpty()) apps else apps.filter { it.label.lowercase().contains(query) || it.pkg.contains(query) }
        l = if (sortByUsage) l.sortedByDescending { Stats.usage(it.pkg) } else l.sortedBy { it.label.lowercase() }
        shown = l
        sortBtn.text = if (sortByUsage) "Most used" else "A-Z"
        appsTitle.text = if (apps.isEmpty()) "APPS" else "APPS  ·  ${shown.size}"
        emptyTv.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        emptyTv.text = if (apps.isEmpty()) "Loading apps…" else "No apps found"
        appAdapter.notifyDataSetChanged()
    }

    private fun refresh() {
        val t = Rules.token(this)
        status.text = if (t == null) "AeroHUB not connected" else "AeroHUB connected"
        (dot.background as GradientDrawable).setColor(if (t == null) GRAY else GREEN)
        val dv = Rules.default(this)
        for ((tab, v) in profiles) {
            val on = v == dv
            tab.background = if (on) ripple(round(Color.WHITE, 12, LINE)) else ripple(round(Color.TRANSPARENT, 12))
            tab.setTextColor(if (on) BLUE else SUB)
        }
        connectBtn.visibility = if (t == null) View.VISIBLE else View.GONE
        vpnSwitch.isChecked = SpeedVpnService.running
        hideSwitch.isChecked = Rules.hideIcon(this)
        defBtn.text = Rules.label(Rules.default(this))
        nightSwitch.isChecked = Rules.nightOn(this)
        nightBtn.text = "${Rules.hm(Rules.nightStart(this))} - ${Rules.hm(Rules.nightEnd(this))}  •  ${Rules.label(Rules.nightLimit(this))}"
        nightBtn.alpha = if (Rules.nightOn(this)) 1f else 0.5f
        appAdapter.notifyDataSetChanged()
        if (t != null) thread { if (MyKuzu.ping(t) == null) runOnUiThread { status.text = "AeroHUB server is off. Start it in AeroHUB"; (dot.background as GradientDrawable).setColor(RED) } }
    }

    // ---- AeroHUB permission
    private fun connectAero() {
        val req = Intent(MyKuzu.ACTION_REQUEST)
        @Suppress("DEPRECATION")
        val found = packageManager.queryIntentActivities(req, 0)
        val target = found.firstOrNull { it.activityInfo.packageName == "com.example.mykuzu" } ?: found.firstOrNull()
        if (target == null) { aeroHelp(); return }
        req.setClassName(target.activityInfo.packageName, target.activityInfo.name)
        try { startActivityForResult(req, REQ_AERO) }
        catch (e: Exception) { toast("Could not open AeroHUB: ${e.javaClass.simpleName} ${e.message ?: ""}") }
    }

    /** AeroHUB did not answer the permission request: explain why and list similar apps that are installed. */
    private fun aeroHelp() {
        val pm = packageManager
        val similar = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName && listOf("kuzu", "aero", "hub").any { k -> it.packageName.lowercase().contains(k) || it.loadLabel(pm).toString().lowercase().contains(k) } }
            .joinToString("\n") { "• ${it.loadLabel(pm)}  (${it.packageName})" }
        val msg = "No app answers the AeroHUB permission request.\n\n" +
            "Expected package: com.example.mykuzu\nExpected action: ${MyKuzu.ACTION_REQUEST}\n\n" +
            (if (similar.isNotEmpty()) "Similar apps found:\n$similar\n\n" else "No AeroHUB app found on this phone.\n\n") +
            "What to do:\n1. Install or update AeroHUB (a version that supports permission requests).\n2. Open AeroHUB once and start its server.\n3. Come back here and tap Connect again."
        AlertDialog.Builder(this).setTitle("AeroHUB not found").setMessage(msg).setPositiveButton("OK", null).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_AERO) {
            if (res == RESULT_OK) {
                val tk = data?.getStringExtra("token")
                if (tk.isNullOrBlank()) toast("AeroHUB replied without a token. Please update AeroHUB.") else { Rules.setToken(this, tk); refresh() }
            } else toast("AeroHUB access was denied or cancelled. Start the AeroHUB server first, then tap Connect again.")
        } else if (req == REQ_VPN) {
            if (res == RESULT_OK) startVpn() else { vpnSwitch.isChecked = false; toast("VPN permission denied") }
        }
    }

    // ---- VPN
    private fun toggleVpn(on: Boolean) {
        if (!on) { startService(Intent(this, SpeedVpnService::class.java).setAction(SpeedVpnService.ACT_STOP)); return }
        val t = Rules.token(this)
        thread {
            if (t != null) Hide.allowVpn(t, packageName)            // skips the system VPN dialog
            runOnUiThread {
                val i = VpnService.prepare(this)
                if (i != null) startActivityForResult(i, REQ_VPN) else startVpn()
            }
        }
    }

    private fun startVpn() {
        startService(Intent(this, SpeedVpnService::class.java).setAction(SpeedVpnService.ACT_START))
        val t = Rules.token(this)
        if (t != null && Rules.hideIcon(this)) thread { Hide.statusIcon(t, true) }
        vpnSwitch.postDelayed({ refresh() }, 600)
    }

    /** rules changed: rebuild the VPN so that the new rules apply */
    private fun reloadVpn() { if (SpeedVpnService.running) startVpn() }

    private fun toggleHide(on: Boolean) {
        val t = Rules.token(this)
        if (t == null) { hideSwitch.isChecked = false; toast("Connect AeroHUB first"); return }
        Rules.setHideIcon(this, on)
        thread { val ok = Hide.statusIcon(t, on); toast(if (ok) (if (on) "VPN icon hidden" else "VPN icon shown") else "Failed. Is the AeroHUB server running?") }
    }

    // ---- pickers
    private fun pick(title: String, includeDefault: Boolean, done: (Long) -> Unit) {
        val items = mutableListOf<Pair<String, Long>>()
        if (includeDefault) items += "Same as others" to Rules.DEFAULT
        items += listOf("Unlimited (full speed)" to Rules.UNLIMITED, "Block internet" to Rules.BLOCK,
            "50 KB/s" to 50L, "100 KB/s" to 100L, "250 KB/s" to 250L, "500 KB/s" to 500L, "1 MB/s" to 1000L, "2 MB/s" to 2000L, "5 MB/s" to 5000L)
        val names = items.map { it.first } + "Custom KB/s..."
        AlertDialog.Builder(this).setTitle(title).setItems(names.toTypedArray()) { _, i ->
            if (i < items.size) done(items[i].second) else number("Custom speed", "KB/s (1 MB/s = 1000)") { done(it) }
        }.show()
    }

    private fun number(title: String, hint: String, done: (Long) -> Unit) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; this.hint = hint }
        AlertDialog.Builder(this).setTitle(title).setView(et).setPositiveButton("OK") { _, _ ->
            et.text.toString().toLongOrNull()?.takeIf { it > 0 }?.let(done)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun nightDialog() {
        val s0 = Rules.nightStart(this); val e0 = Rules.nightEnd(this)
        TimePickerDialog(this, { _, h, m ->
            val st = h * 60 + m
            TimePickerDialog(this, { _, h2, m2 ->
                val en = h2 * 60 + m2
                pick("During the night", false) { v ->
                    Rules.setNight(this, true, st, en, v); refresh(); reloadVpn()
                }
            }, e0 / 60, e0 % 60, true).apply { setTitle("Night ends at") }.show()
        }, s0 / 60, s0 % 60, true).apply { setTitle("Night starts at") }.show()
    }

    // ---- one app, all its controls (rounded sheet)
    private fun detail(a: App) {
        val c = this
        val d = Dialog(c)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(16)); background = round(Color.WHITE, 24)
        }
        d.setContentView(ScrollView(c).apply { addView(box) })
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((c.resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)

        fun render() {
            box.removeAllViews()
            val lim = Rules.get(c, a.pkg); val net = Rules.net(c, a.pkg); val q = Rules.quota(c, a.pkg); val bg = Rules.bgBlocked(c, a.pkg)
            fun changed() { filter(); reloadVpn(); render() }
            fun item(title: String, sub: String?, value: String, onClick: () -> Unit) {
                box.addView(divider())
                box.addView(row(title, sub, txt("$value  ›", 13f, BLUE, true), onClick))
            }

            val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
            val ic = ImageView(c).apply { try { setImageDrawable(packageManager.getApplicationIcon(a.pkg)) } catch (_: Exception) {} }
            head.addView(ic, LinearLayout.LayoutParams(dp(48), dp(48)))
            val hc = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0)
                addView(txt(a.label, 18f, INK, true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END })
                addView(txt("Used today: ${Stats.fmt(Stats.usage(a.pkg))}", 12f, SUB).apply { setPadding(0, dp(2), 0, 0) })
            }
            head.addView(hc, lpw())
            box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })

            item("Speed limit", null, Rules.label(lim)) { pick(a.label, true) { Rules.set(c, a.pkg, it); changed() } }
            item("Network", null, Rules.netLabel(net)) {
                AlertDialog.Builder(c).setTitle("Allowed network").setItems(arrayOf("Wi-Fi + Mobile", "Wi-Fi only", "Mobile data only")) { _, k -> Rules.setNet(c, a.pkg, k); changed() }.show()
            }
            item("Daily data quota", "Resets at midnight", quotaLabel(q)) {
                val opts = listOf("Off" to 0L, "50 MB" to 50L, "100 MB" to 100L, "500 MB" to 500L, "1 GB" to 1000L, "2 GB" to 2000L, "5 GB" to 5000L)
                AlertDialog.Builder(c).setTitle("Daily quota (resets at midnight)").setItems((opts.map { it.first } + "Custom MB...").toTypedArray()) { _, k ->
                    if (k < opts.size) { Rules.setQuota(c, a.pkg, opts[k].second); changed() } else number("Custom quota", "MB per day") { Rules.setQuota(c, a.pkg, it); changed() }
                }.show()
            }
            item("Background data", "Needs AeroHUB", if (bg) "Blocked" else "Allowed") {
                val t = Rules.token(c)
                val uid = try { packageManager.getApplicationInfo(a.pkg, 0).uid } catch (_: Exception) { -1 }
                if (t == null) toast("Connect AeroHUB first") else thread {
                    val ok = Hide.background(t, uid, !bg)
                    if (ok) Rules.setBgBlocked(c, a.pkg, !bg)
                    toast(if (ok) (if (!bg) "Background data blocked" else "Background data allowed") else "Failed. Is the AeroHUB server running?")
                    runOnUiThread { filter(); render() }
                }
            }
            item("Used today", "Tap to reset", Stats.fmt(Stats.usage(a.pkg))) { Stats.reset(c, a.pkg); changed() }

            val br = LinearLayout(c)
            br.addView(outlineBtn("Force stop") {
                val t = Rules.token(c)
                if (t == null) toast("Connect AeroHUB first") else thread { try { MyKuzu.forceStop(t, a.pkg); toast("Stopped ${a.label}") } catch (_: Exception) { toast("Failed") } }
            }, lpw().apply { rightMargin = dp(8) })
            br.addView(outlineBtn("Reset rules", true) {
                if (bg) Rules.token(c)?.let { t -> thread { Hide.background(t, try { packageManager.getApplicationInfo(a.pkg, 0).uid } catch (_: Exception) { -1 }, false) } }
                Rules.resetApp(c, a.pkg); changed()
            }, lpw())
            box.addView(br, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
            box.addView(filledBtn("Done") { d.dismiss() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        render()
        d.show()
    }

    private fun chip(t: String, bg: Int, fg: Int) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(fg); background = round(bg, 8); setPadding(dp(7), dp(2), dp(7), dp(2)); setTypeface(null, Typeface.BOLD)
    }

    private fun chips(a: App): List<TextView> {
        val l = mutableListOf<TextView>()
        val lim = Rules.get(this, a.pkg)
        when {
            lim == Rules.BLOCK -> l += chip("Blocked", 0xFFFEE2E2.toInt(), 0xFFB91C1C.toInt())
            lim == Rules.UNLIMITED -> l += chip("Unlimited", 0xFFDCFCE7.toInt(), 0xFF15803D.toInt())
            lim > 0 -> l += chip(Rules.label(lim), 0xFFDBEAFE.toInt(), 0xFF1D4ED8.toInt())
        }
        val n = Rules.net(this, a.pkg); if (n == 1) l += chip("Wi-Fi only", 0xFFF3E8FF.toInt(), 0xFF7E22CE.toInt()); if (n == 2) l += chip("Mobile only", 0xFFF3E8FF.toInt(), 0xFF7E22CE.toInt())
        val q = Rules.quota(this, a.pkg); if (q > 0) l += chip("Quota ${quotaLabel(q)}", 0xFFFEF3C7.toInt(), 0xFFB45309.toInt())
        if (Rules.bgBlocked(this, a.pkg)) l += chip("No background", 0xFFF3F4F6.toInt(), 0xFF374151.toInt())
        return l
    }

    private fun makeAdapter() = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val a = shown[p]
            val ctx = this@MainActivity
            val row = LinearLayout(ctx).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = ripple(round(Color.WHITE, 16, LINE))
                setOnClickListener { detail(a) }
            }
            val ic = ImageView(ctx).apply { try { setImageDrawable(packageManager.getApplicationIcon(a.pkg)) } catch (_: Exception) {} }
            row.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
            col.addView(txt(a.label, 15f, INK, true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END })
            val cs = chips(a)
            if (cs.isNotEmpty()) {
                val cr = LinearLayout(ctx).apply { setPadding(0, dp(4), 0, 0) }
                for (c in cs.take(3)) cr.addView(c, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(4) })
                col.addView(cr)
            } else {
                col.addView(txt("Follows default rule", 12f, SUB).apply { setPadding(0, dp(2), 0, 0) })
            }
            row.addView(col, lpw())
            val u = Stats.usage(a.pkg)
            if (u > 0) row.addView(txt(Stats.fmt(u), 12f, SUB))
            row.addView(txt("›", 22f, SUB).apply { setPadding(dp(8), 0, 0, 0) })
            val w = FrameLayout(ctx)
            w.setPadding(dp(14), dp(4), dp(14), dp(4))
            w.addView(row, FrameLayout.LayoutParams(MATCH, WRAP))
            return w
        }
    }
}
