package com.aerohub.speed

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** Data used today per app (only traffic that goes through the VPN is counted) and live totals. */
object Stats {
    val today = ConcurrentHashMap<String, AtomicLong>()
    val down = AtomicLong()
    val up = AtomicLong()
    @Volatile var day = ""

    private fun now() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    @Synchronized fun load(c: Context) {
        val p = c.getSharedPreferences("usage", Context.MODE_PRIVATE); val d = now()
        if (day == d && today.isNotEmpty()) return
        if (p.getString("_day", "") != d) { p.edit().clear().putString("_day", d).apply(); today.clear(); day = d; return }
        today.clear()
        for ((k, v) in p.all) if (k != "_day" && v is Long) today[k] = AtomicLong(v)
        day = d
    }

    @Synchronized fun rollover() { val d = now(); if (day != d) { today.clear(); day = d } }

    fun add(pkg: String, n: Long, isDown: Boolean) {
        today.getOrPut(pkg) { AtomicLong() }.addAndGet(n)
        (if (isDown) down else up).addAndGet(n)
    }

    fun usage(pkg: String): Long = today[pkg]?.get() ?: 0L
    fun reset(c: Context, pkg: String) { today.remove(pkg); save(c) }

    @Synchronized fun save(c: Context) {
        val e = c.getSharedPreferences("usage", Context.MODE_PRIVATE).edit().clear().putString("_day", day)
        for ((k, v) in today) e.putLong(k, v.get())
        e.apply()
    }

    fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1024 -> "%d KB".format(b / 1024)
        else -> "$b B"
    }
}
