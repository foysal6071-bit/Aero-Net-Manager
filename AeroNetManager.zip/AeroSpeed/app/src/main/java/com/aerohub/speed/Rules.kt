package com.aerohub.speed

import android.content.Context

/** Speed rules. Values are KB/s (both directions). */
object Rules {
    const val UNLIMITED = 0L   // bypasses the VPN completely
    const val BLOCK = -1L      // no internet
    const val DEFAULT = -2L    // follow the "all other apps" rule

    private fun p(c: Context) = c.getSharedPreferences("speed", Context.MODE_PRIVATE)

    fun get(c: Context, pkg: String): Long = p(c).getLong("r_$pkg", DEFAULT)
    fun set(c: Context, pkg: String, v: Long) { p(c).edit().apply { if (v == DEFAULT) remove("r_$pkg") else putLong("r_$pkg", v) }.apply() }

    fun default(c: Context): Long = p(c).getLong("default", UNLIMITED)
    fun setDefault(c: Context, v: Long) { p(c).edit().putLong("default", v).apply() }

    /** package -> limit, only explicit rules */
    fun all(c: Context): Map<String, Long> =
        p(c).all.filterKeys { it.startsWith("r_") }.mapKeys { it.key.removePrefix("r_") }.mapValues { (it.value as Long) }

    fun token(c: Context): String? = p(c).getString("token", null)
    fun setToken(c: Context, v: String?) { p(c).edit().putString("token", v).apply() }

    // ---- allowed networks: 0 = Wi-Fi + mobile, 1 = Wi-Fi only, 2 = mobile only
    fun net(c: Context, pkg: String) = p(c).getInt("n_$pkg", 0)
    fun setNet(c: Context, pkg: String, v: Int) { p(c).edit().apply { if (v == 0) remove("n_$pkg") else putInt("n_$pkg", v) }.apply() }
    fun netLabel(v: Int) = when (v) { 1 -> "Wi-Fi only"; 2 -> "Mobile data only"; else -> "Wi-Fi + Mobile" }

    // ---- daily data quota in MB (0 = off)
    fun quota(c: Context, pkg: String) = p(c).getLong("q_$pkg", 0L)
    fun setQuota(c: Context, pkg: String, mb: Long) { p(c).edit().apply { if (mb <= 0) remove("q_$pkg") else putLong("q_$pkg", mb) }.apply() }

    // ---- background data (system Data Saver blacklist, set through AeroHUB)
    fun bgBlocked(c: Context, pkg: String) = p(c).getBoolean("b_$pkg", false)
    fun setBgBlocked(c: Context, pkg: String, v: Boolean) { p(c).edit().apply { if (!v) remove("b_$pkg") else putBoolean("b_$pkg", true) }.apply() }

    // ---- night schedule
    fun nightOn(c: Context) = p(c).getBoolean("night_on", false)
    fun nightStart(c: Context) = p(c).getInt("night_start", 23 * 60)
    fun nightEnd(c: Context) = p(c).getInt("night_end", 6 * 60)
    fun nightLimit(c: Context) = p(c).getLong("night_limit", BLOCK)
    fun setNight(c: Context, on: Boolean, start: Int = nightStart(c), end: Int = nightEnd(c), limit: Long = nightLimit(c)) {
        p(c).edit().putBoolean("night_on", on).putInt("night_start", start).putInt("night_end", end).putLong("night_limit", limit).apply()
    }
    fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)

    /** every package that has at least one rule */
    fun packagesWithRules(c: Context): Set<String> =
        p(c).all.keys.filter { it.length > 2 && it[1] == '_' && it[0] in "rnqb" }.map { it.substring(2) }.toSet()

    fun resetApp(c: Context, pkg: String) { p(c).edit().remove("r_$pkg").remove("n_$pkg").remove("q_$pkg").remove("b_$pkg").apply() }
    fun resetAll(c: Context) { p(c).edit().apply { for (k in p(c).all.keys) if (k.length > 2 && k[1] == '_' && k[0] in "rnqb") remove(k); remove("default"); remove("night_on") }.apply() }

    fun hideIcon(c: Context) = p(c).getBoolean("hide", false)
    fun setHideIcon(c: Context, v: Boolean) { p(c).edit().putBoolean("hide", v).apply() }

    fun label(v: Long): String = when {
        v == DEFAULT -> "Same as others"
        v == UNLIMITED -> "Unlimited"
        v == BLOCK -> "Blocked"
        v >= 1000 -> (if (v % 1000 == 0L) "${v / 1000}" else "%.1f".format(v / 1000.0)) + " MB/s"
        else -> "$v KB/s"
    }
}
