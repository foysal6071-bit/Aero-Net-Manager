package com.aerohub.speed

/** Uses AeroHUB's elevated access to prepare the VPN and to hide the VPN key icon in the status bar. */
object Hide {
    /** Lets this app start the VPN without the system consent dialog. */
    fun allowVpn(token: String, pkg: String) = try { MyKuzu.exec(token, "cmd appops set $pkg ACTIVATE_VPN allow").first == 0 } catch (_: Exception) { false }

    /** Adds/removes "vpn" in the status bar icon blacklist, keeping the other hidden icons. */
    fun statusIcon(token: String, hide: Boolean): Boolean = try {
        val cur = MyKuzu.getSetting(token, "secure", "icon_blacklist")
        val list = (if (cur.isBlank() || cur == "null") emptyList() else cur.split(",")).filter { it.isNotBlank() && it != "vpn" }.toMutableList()
        if (hide) list.add("vpn")
        if (list.isEmpty()) MyKuzu.exec(token, "settings delete secure icon_blacklist").first == 0
        else MyKuzu.putSetting(token, "secure", "icon_blacklist", list.joinToString(",")).first == 0
    } catch (_: Exception) { false }

    /** Blocks/unblocks background data for one app (system per-app "Background data" policy). */
    fun background(token: String, uid: Int, block: Boolean) = try {
        MyKuzu.exec(token, "cmd netpolicy ${if (block) "add" else "remove"} restrict-background-blacklist $uid").first == 0
    } catch (_: Exception) { false }
}
