include $(call all-subdir-makefile)
