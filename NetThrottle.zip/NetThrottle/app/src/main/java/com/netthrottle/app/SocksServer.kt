package com.netthrottle.app
import android.net.VpnService
import java.io.InputStream
import java.net.*
import kotlin.concurrent.thread

class Limiter(private val rate: Long) {
    private var next = System.nanoTime()
    fun acquire(n: Int) {
        if (rate <= 0) return
        val wait: Long
        synchronized(this) {
            val now = System.nanoTime()
            if (next < now) next = now
            next += n * 1_000_000_000L / rate
            wait = next - now
        }
        if (wait > 50_000_000L) Thread.sleep((wait - 50_000_000L) / 1_000_000L)
    }
}

/** Local SOCKS5 (CONNECT only) that throttles upload/download and adds latency. */
class SocksServer(private val vpn: VpnService, dlKB: Long, ulKB: Long, private val pingMs: Int) {
    private val server = ServerSocket(0, 128, InetAddress.getByName("127.0.0.1"))
    val port get() = server.localPort
    private val dl = Limiter(dlKB * 1024)
    private val ul = Limiter(ulKB * 1024)
    @Volatile private var alive = true

    fun start() { thread(isDaemon = true) {
        while (alive) try { val c = server.accept(); thread(isDaemon = true) { handle(c) } } catch (_: Exception) { break }
    } }
    fun stop() { alive = false; try { server.close() } catch (_: Exception) {} }

    private fun InputStream.readN(n: Int): ByteArray {
        val b = ByteArray(n); var o = 0
        while (o < n) { val r = read(b, o, n - o); if (r < 0) throw java.io.IOException(); o += r }
        return b
    }

    private fun handle(c: Socket) {
        var r: Socket? = null
        try {
            val i = c.getInputStream(); val o = c.getOutputStream()
            val h = i.readN(2); i.readN(h[1].toInt() and 0xff); o.write(byteArrayOf(5, 0))
            val q = i.readN(4)
            val host = when (q[3].toInt()) {
                1 -> InetAddress.getByAddress(i.readN(4)).hostAddress!!
                4 -> InetAddress.getByAddress(i.readN(16)).hostAddress!!
                3 -> String(i.readN(i.readN(1)[0].toInt() and 0xff))
                else -> throw java.io.IOException()
            }
            val pb = i.readN(2); val port = ((pb[0].toInt() and 0xff) shl 8) or (pb[1].toInt() and 0xff)
            if (q[1].toInt() != 1) { o.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); c.close(); return }
            if (pingMs > 0) Thread.sleep(pingMs.toLong())
            r = Socket(); vpn.protect(r); r.connect(InetSocketAddress(host, port), 10000)
            o.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); o.flush()
            val rr = r
            thread(isDaemon = true) { pump(c.getInputStream(), rr.getOutputStream(), ul, pingMs / 2, c, rr) }
            pump(rr.getInputStream(), c.getOutputStream(), dl, pingMs / 2, c, rr)
        } catch (_: Exception) { try { c.close() } catch (_: Exception) {}; try { r?.close() } catch (_: Exception) {} }
    }

    private fun pump(src: InputStream, dst: java.io.OutputStream, lim: Limiter, delay: Int, a: Socket, b: Socket) {
        val buf = ByteArray(8192)
        try {
            while (true) {
                val n = src.read(buf); if (n < 0) break
                if (delay > 0) Thread.sleep(delay.toLong())
                lim.acquire(n); dst.write(buf, 0, n); dst.flush()
            }
        } catch (_: Exception) {}
        try { a.close() } catch (_: Exception) {}; try { b.close() } catch (_: Exception) {}
    }
}
