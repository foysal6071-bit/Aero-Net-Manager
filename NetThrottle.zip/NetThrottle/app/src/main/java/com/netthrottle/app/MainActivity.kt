package com.netthrottle.app
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.graphics.drawable.toBitmap

data class AppItem(val name: String, val pkg: String, val icon: androidx.compose.ui.graphics.ImageBitmap)

class MainActivity : ComponentActivity() {
    private var pending: (() -> Unit)? = null
    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) pending?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }.distinctBy { it.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.packageName, it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()) }
            .sortedBy { it.name.lowercase() }
    }

    private fun start(pkgs: Set<String>, dl: Long, ul: Long, ping: Int) {
        val go = {
            androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, ThrottleService::class.java).putExtra("pkgs", pkgs.toTypedArray())
                .putExtra("dl", dl).putExtra("ul", ul).putExtra("ping", ping))
        }
        val p = VpnService.prepare(this)
        if (p == null) go() else { pending = { go() }; launcher.launch(p) }
    }

    @Composable
    fun Screen() {
        val prefs = remember { getSharedPreferences("p", 0) }
        val apps = remember { loadApps() }
        var dl by remember { mutableStateOf(prefs.getFloat("dl", 300f)) }
        var ul by remember { mutableStateOf(prefs.getFloat("ul", 150f)) }
        var ping by remember { mutableStateOf(prefs.getFloat("ping", 100f)) }
        var mode by remember { mutableStateOf(prefs.getInt("mode", 1)) }
        var sel by remember { mutableStateOf(prefs.getStringSet("sel", emptySet())!!.toSet()) }
        var q by remember { mutableStateOf("") }
        fun save() = prefs.edit().putFloat("dl", dl).putFloat("ul", ul).putFloat("ping", ping)
            .putInt("mode", mode).putStringSet("sel", sel).apply()
        fun preset(i: Int, d: Float, u: Float, p: Float) { mode = i; dl = d; ul = u; ping = p; save() }
        val on = ThrottleService.running

        @Composable
        fun Chip(i: Int, text: String, onClick: () -> Unit, m: Modifier) {
            if (mode == i) Button(onClick, m, contentPadding = PaddingValues(4.dp)) { Text(text, maxLines = 1) }
            else OutlinedButton(onClick, m, contentPadding = PaddingValues(4.dp)) { Text(text, maxLines = 1) }
        }

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
            Text("NetThrottle v8", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    save()
                    prefs.edit().putBoolean("on", !on).apply()
                    if (on) startService(Intent(this@MainActivity, ThrottleService::class.java).setAction("STOP"))
                    else start(sel, dl.toLong(), ul.toLong(), ping.toInt())
                },
                enabled = on || sel.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text(if (on) "STOP" else "START", style = MaterialTheme.typography.titleLarge) }
            Text(
                if (on) "Running on ${sel.size} apps" else if (sel.isEmpty()) "Select apps below, then press START" else "${sel.size} apps selected",
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp)
            )
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({
                    try { startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        android.net.Uri.parse("package:$packageName"))) } catch (_: Exception) {}
                }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Battery: allow", maxLines = 1) }
                OutlinedButton({
                    try { startActivity(Intent().setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")) }
                    catch (_: Exception) { try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:$packageName"))) } catch (_: Exception) {} }
                }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Autostart", maxLines = 1) }
            }
            if (ThrottleService.lastError.isNotEmpty())
                androidx.compose.foundation.text.selection.SelectionContainer {
                    Text(ThrottleService.lastError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            Text("Speed", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val m = Modifier.weight(1f)
                Chip(0, "Slow", { preset(0, 50f, 25f, 300f) }, m)
                Chip(1, "Medium", { preset(1, 300f, 150f, 100f) }, m)
                Chip(2, "Fast", { preset(2, 1500f, 800f, 0f) }, m)
                Chip(3, "Custom", { mode = 3; save() }, m)
            }
            if (mode == 3) {
                fun lbl(v: Float) = if (v < 1f) "Unlimited" else "${v.toInt()} KB/s"
                Text("Download: ${lbl(dl)}"); Slider(dl, { dl = it }, valueRange = 0f..5000f, onValueChangeFinished = { save() })
                Text("Upload: ${lbl(ul)}"); Slider(ul, { ul = it }, valueRange = 0f..5000f, onValueChangeFinished = { save() })
                Text("Ping: +${ping.toInt()} ms"); Slider(ping, { ping = it }, valueRange = 0f..1000f, onValueChangeFinished = { save() })
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(q, { q = it }, label = { Text("Search apps") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            LazyColumn(Modifier.weight(1f)) {
                items(apps.filter { it.name.contains(q, true) }, key = { it.pkg }) { a ->
                    Row(Modifier.fillMaxWidth().clickable { sel = if (a.pkg in sel) sel - a.pkg else sel + a.pkg; save() }
                        .padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(a.icon, null, Modifier.size(40.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(a.name, Modifier.weight(1f))
                        Checkbox(a.pkg in sel, { sel = if (it) sel + a.pkg else sel - a.pkg; save() })
                    }
                }
            }
        }
    }
}
