package com.netthrottle.app
object TProxy {
    var loadError: String? = null
    init {
        try { System.loadLibrary("hev-socks5-tunnel") }
        catch (e: Throwable) { loadError = e.javaClass.simpleName + ": " + e.message }
    }
    @JvmStatic external fun TProxyStartService(configPath: String, fd: Int)
    @JvmStatic external fun TProxyStopService()
}
