package com.netthrottle.app
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Watchdog {
    const val ACTION = "com.netthrottle.WATCHDOG"
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 7,
        Intent(c, BootReceiver::class.java).setAction(ACTION), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    fun schedule(c: Context, delayMs: Long) {
        try { c.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delayMs, pi(c)) } catch (_: Exception) {}
    }
    fun cancel(c: Context) { try { c.getSystemService(AlarmManager::class.java).cancel(pi(c)) } catch (_: Exception) {} }
}
