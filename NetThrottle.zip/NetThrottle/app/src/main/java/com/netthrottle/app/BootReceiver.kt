package com.netthrottle.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Watchdog.ACTION) return
        val p = c.getSharedPreferences("p", 0)
        val sel = p.getStringSet("sel", emptySet())!!
        if (!p.getBoolean("on", false) || sel.isEmpty()) return
        Watchdog.schedule(c, 5 * 60_000L)
        if (ThrottleService.running) return
        if (VpnService.prepare(c) != null) return // VPN permission not granted yet
        ContextCompat.startForegroundService(c, Intent(c, ThrottleService::class.java).putExtra("pkgs", sel.toTypedArray())
            .putExtra("dl", p.getFloat("dl", 0f).toLong()).putExtra("ul", p.getFloat("ul", 0f).toLong())
            .putExtra("ping", p.getFloat("ping", 0f).toInt()))
    }
}
