package com.netthrottle.app
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

class ThrottleService : VpnService() {
    companion object { var running by mutableStateOf(false) }
    private var tun: ParcelFileDescriptor? = null
    private var socks: SocksServer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopAll(); stopSelf(); return START_NOT_STICKY }
        stopAll()
        val pkgs = intent?.getStringArrayExtra("pkgs") ?: return START_NOT_STICKY
        val dl = intent.getLongExtra("dl", 0); val ul = intent.getLongExtra("ul", 0); val ping = intent.getIntExtra("ping", 0)
        try {
            socks = SocksServer(this, dl, ul, ping).also { it.start() }
            val b = Builder().setSession("NetThrottle").setMtu(1500)
                .addAddress("198.18.0.1", 32).addRoute("0.0.0.0", 0).addDnsServer("198.18.0.2")
            pkgs.forEach { try { b.addAllowedApplication(it) } catch (_: Exception) {} }
            tun = b.establish() ?: throw IllegalStateException("VPN denied")
            val cfg = File(cacheDir, "tproxy.yml")
            cfg.writeText("""
tunnel:
  mtu: 1500
  ipv4: 198.18.0.1
socks5:
  port: ${socks!!.port}
  address: 127.0.0.1
mapdns:
  address: 198.18.0.2
  port: 53
  network: 100.64.0.0
  netmask: 255.192.0.0
  cache-size: 10000
""".trimStart())
            TProxy.TProxyStartService(cfg.absolutePath, tun!!.fd)
            running = true
        } catch (e: Throwable) { stopAll(); stopSelf() }
        return START_STICKY
    }

    private fun stopAll() {
        try { TProxy.TProxyStopService() } catch (_: Throwable) {}
        socks?.stop(); socks = null
        try { tun?.close() } catch (_: Exception) {}; tun = null
        running = false
    }
    override fun onRevoke() { stopAll(); super.onRevoke() }
    override fun onDestroy() { stopAll(); super.onDestroy() }
}
