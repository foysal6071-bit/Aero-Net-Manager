package com.netthrottle.app
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.io.File

class ThrottleService : VpnService() {
    companion object {
        var running by mutableStateOf(false)
        var lastError by mutableStateOf("")
    }
    private var tun: ParcelFileDescriptor? = null
    private var socks: SocksServer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == "STOP") { Watchdog.cancel(this); stopAll(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        stopAll(); lastError = ""
        Watchdog.schedule(this, 5 * 60_000L)
        var pkgs = intent?.getStringArrayExtra("pkgs")
        var dl = intent?.getLongExtra("dl", 0) ?: 0L
        var ul = intent?.getLongExtra("ul", 0) ?: 0L
        var ping = intent?.getIntExtra("ping", 0) ?: 0
        if (pkgs == null) { // restarted by the system: restore saved settings
            val p = getSharedPreferences("p", 0)
            if (!p.getBoolean("on", false)) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            pkgs = p.getStringSet("sel", emptySet())!!.toTypedArray()
            dl = p.getFloat("dl", 0f).toLong(); ul = p.getFloat("ul", 0f).toLong(); ping = p.getFloat("ping", 0f).toInt()
        }
        try {
            TProxy.loadError?.let { throw IllegalStateException(it) }
            socks = SocksServer(this, dl, ul, ping).also { it.start() }
            val b = Builder().setSession("NetThrottle").setMtu(1500)
                .addAddress("198.18.0.1", 32).addRoute("0.0.0.0", 0).addDnsServer("198.18.0.2")
            pkgs.forEach { try { b.addAllowedApplication(it) } catch (_: Exception) {} }
            tun = b.establish() ?: throw IllegalStateException("VPN denied")
            val cfg = File(cacheDir, "tproxy.yml")
            cfg.writeText("""
tunnel:
  mtu: 1500
  ipv4: 198.18.0.1
socks5:
  port: ${socks!!.port}
  address: 127.0.0.1
mapdns:
  address: 198.18.0.2
  port: 53
  network: 100.64.0.0
  netmask: 255.192.0.0
  cache-size: 10000
""".trimStart())
            TProxy.TProxyStartService(cfg.absolutePath, tun!!.fd)
            running = true
        } catch (e: Throwable) {
            lastError = e.javaClass.simpleName + ": " + e.message
            val m = "VPN error: " + e.javaClass.simpleName + ": " + e.message
            Handler(Looper.getMainLooper()).post { Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show() }
            stopAll(); stopSelf()
        }
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vpn", "NetThrottle", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "vpn").setContentTitle("NetThrottle is running")
            .setContentText("Tap to open").setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
    }

    override fun onTaskRemoved(rootIntent: Intent?) { Watchdog.schedule(this, 1500) }

    private fun stopAll() {
        if (TProxy.loadError == null) try { TProxy.TProxyStopService() } catch (_: Throwable) {}
        socks?.stop(); socks = null
        try { tun?.close() } catch (_: Exception) {}; tun = null
        running = false
    }
    override fun onRevoke() { stopAll(); super.onRevoke() }
    override fun onDestroy() {
        stopAll()
        if (getSharedPreferences("p", 0).getBoolean("on", false)) Watchdog.schedule(this, 1500)
        super.onDestroy()
    }
}
