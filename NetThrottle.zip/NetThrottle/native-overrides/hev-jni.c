/* Minimal JNI wrapper (replaces upstream hev-jni.c) for com.netthrottle.app.TProxy */
#include <jni.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

extern int hev_socks5_tunnel_main (const char *config_path, int tun_fd);
extern void hev_socks5_tunnel_quit (void);

static pthread_t work_thread;
static int working = 0;
static pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;

typedef struct { char *path; int fd; } Arg;

static void *run (void *p)
{
    Arg *a = (Arg *)p;
    hev_socks5_tunnel_main (a->path, a->fd);
    free (a->path);
    free (a);
    return NULL;
}

JNIEXPORT void JNICALL
Java_com_netthrottle_app_TProxy_TProxyStartService (JNIEnv *env, jclass cls, jstring path, jint fd)
{
    pthread_mutex_lock (&mu);
    if (!working) {
        const char *s = (*env)->GetStringUTFChars (env, path, NULL);
        Arg *a = (Arg *)malloc (sizeof (Arg));
        a->path = strdup (s);
        a->fd = fd;
        (*env)->ReleaseStringUTFChars (env, path, s);
        if (pthread_create (&work_thread, NULL, run, a) == 0) {
            working = 1;
        } else {
            free (a->path);
            free (a);
        }
    }
    pthread_mutex_unlock (&mu);
}

JNIEXPORT void JNICALL
Java_com_netthrottle_app_TProxy_TProxyStopService (JNIEnv *env, jclass cls)
{
    pthread_mutex_lock (&mu);
    if (working) {
        hev_socks5_tunnel_quit ();
        pthread_join (work_thread, NULL);
        working = 0;
    }
    pthread_mutex_unlock (&mu);
}
